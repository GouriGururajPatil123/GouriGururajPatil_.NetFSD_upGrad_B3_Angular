CREATE DATABASE ProductDb;

USE ProductDb;

CREATE TABLE Products
(
    ProductId INT PRIMARY KEY IDENTITY,
    ProductName VARCHAR(100),
    Category VARCHAR(50),
    Price DECIMAL(10,2)
);

/* Create Stored Procedures*/

-- INSERT
CREATE PROCEDURE sp_InsertProduct
    @ProductName VARCHAR(100),
    @Category VARCHAR(50),
    @Price DECIMAL(10,2)
AS
BEGIN
    INSERT INTO Products(ProductName, Category, Price)
    VALUES(@ProductName, @Category, @Price)
END
GO

-- GET ALL
CREATE PROCEDURE sp_GetAllProducts
AS
BEGIN
    SELECT * FROM Products
END
GO

-- UPDATE
CREATE PROCEDURE sp_UpdateProduct
    @ProductId INT,
    @ProductName VARCHAR(100),
    @Category VARCHAR(50),
    @Price DECIMAL(10,2)
AS
BEGIN
    UPDATE Products
    SET ProductName=@ProductName,
        Category=@Category,
        Price=@Price
    WHERE ProductId=@ProductId
END
GO

-- DELETE
CREATE PROCEDURE sp_DeleteProduct
    @ProductId INT
AS
BEGIN
    DELETE FROM Products WHERE ProductId=@ProductId
END
GO

SELECT * FROM Products

CREATE PROCEDURE GetProductById    @ProductId INTASBEGIN    SELECT * FROM Products WHERE ProductId=@ProductId;END