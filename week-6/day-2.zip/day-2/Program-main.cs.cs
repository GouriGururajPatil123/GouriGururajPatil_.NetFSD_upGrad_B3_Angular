﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        ProductDAL dal = new ProductDAL();

        while (true)
        {
            Console.WriteLine("\n1.Insert 2.View 3.Update 4.Delete 5.Exit");
            Console.Write("Enter choice: ");
            int ch = int.Parse(Console.ReadLine());

            try
            {
                if (ch == 1)
                {
                    Product p = new Product();

                    Console.Write("Name: ");
                    p.ProductName = Console.ReadLine();

                    Console.Write("Category: ");
                    p.Category = Console.ReadLine();

                    Console.Write("Price: ");
                    p.Price = decimal.Parse(Console.ReadLine());

                    dal.InsertProduct(p);
                    Console.WriteLine("Inserted Successfully");
                }
                else if (ch == 2)
                {
                    List<Product> list = dal.GetAllProducts();

                    foreach (Product item in list)
                    {
                        Console.WriteLine(item);
                    }
                }
                else if (ch == 3)
                {
                    Product p = new Product();

                    Console.Write("ID: ");
                    p.ProductId = int.Parse(Console.ReadLine());

                    Console.Write("Name: ");
                    p.ProductName = Console.ReadLine();

                    Console.Write("Category: ");
                    p.Category = Console.ReadLine();

                    Console.Write("Price: ");
                    p.Price = decimal.Parse(Console.ReadLine());

                    dal.UpdateProduct(p);
                    Console.WriteLine("Updated Successfully");
                }
                else if (ch == 4)
                {
                    Console.Write("Enter ID: ");
                    int id = int.Parse(Console.ReadLine());

                    dal.DeleteProduct(id);
                    Console.WriteLine("Deleted Successfully");
                }
                else if (ch == 5)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid choice");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}