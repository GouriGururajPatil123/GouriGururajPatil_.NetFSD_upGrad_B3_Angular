﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

public class ProductDAL
{
    private string connStr;

    //Constructor
    public ProductDAL()
    {
        //Reads appsettings.json
        var config = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json")
            .Build();

        connStr = config.GetConnectionString("DefaultConnection");
    }

    // INSERT METHOD
    public void InsertProduct(Product p)
    {
        using (SqlConnection con = new SqlConnection(connStr))
        {
            SqlCommand cmd = new SqlCommand("sp_InsertProduct", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ProductName", p.ProductName);
            cmd.Parameters.AddWithValue("@Category", p.Category);
            cmd.Parameters.AddWithValue("@Price", p.Price);

            con.Open();
            cmd.ExecuteNonQuery();
        }
    }

    // GET ALL
    public List<Product> GetAllProducts()
    {
        List<Product> list = new List<Product>();

        using (SqlConnection con = new SqlConnection(connStr))
        {
            SqlCommand cmd = new SqlCommand("sp_GetAllProducts", con);
            cmd.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Product p = new Product();
                p.ProductId = (int)reader["ProductId"];
                p.ProductName = reader["ProductName"].ToString();
                p.Category = reader["Category"].ToString();
                p.Price = (decimal)reader["Price"];

                list.Add(p);
            }

            reader.Close();
        }

        return list;
    }

    // UPDATE
    public void UpdateProduct(Product p)
    {
        using (SqlConnection con = new SqlConnection(connStr))
        {
            SqlCommand cmd = new SqlCommand("sp_UpdateProduct", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ProductId", p.ProductId);
            cmd.Parameters.AddWithValue("@ProductName", p.ProductName);
            cmd.Parameters.AddWithValue("@Category", p.Category);
            cmd.Parameters.AddWithValue("@Price", p.Price);

            con.Open();
            cmd.ExecuteNonQuery();
        }
    }

    // DELETE
    public void DeleteProduct(int id)
    {
        using (SqlConnection con = new SqlConnection(connStr))
        {
            SqlCommand cmd = new SqlCommand("sp_DeleteProduct", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ProductId", id);

            con.Open();
            cmd.ExecuteNonQuery();
        }
    }
}
