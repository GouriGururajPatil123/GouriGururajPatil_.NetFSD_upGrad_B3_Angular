﻿using Microsoft.AspNetCore.Mvc;
using ProductCRUDApp.Models;

namespace ProductCRUDApp.Controllers
{
    public class ProductController : Controller
    {
        public static List<Product> products = new List<Product>
        {
            new Product { ProductId = 1, ProductName = "Laptop", Price = 50000, Category = "Electronics" },
            new Product { ProductId = 2, ProductName = "Mobile", Price = 20000, Category = "Electronics" }
        };

        // READ
        public IActionResult Index()
        {
            return View(products);
        }

        // DETAILS
        public IActionResult Details(int id)
        {
            var product = products.FirstOrDefault(p => p.ProductId == id);
            return View(product);
        }

        // CREATE GET
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // CREATE POST
        [HttpPost]
        public IActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                products.Add(product);
                return RedirectToAction("Index");
            }
            return View(product);
        }

        // EDIT GET
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var product = products.FirstOrDefault(p => p.ProductId == id);
            return View(product);
        }

        // EDIT POST
        [HttpPost]
        public IActionResult Edit(Product product)
        {
            var existing = products.FirstOrDefault(p => p.ProductId == product.ProductId);

            if (existing != null && ModelState.IsValid)
            {
                existing.ProductName = product.ProductName;
                existing.Price = product.Price;
                existing.Category = product.Category;

                return RedirectToAction("Index");
            }

            return View(product);
        }

        // DELETE GET
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var product = products.FirstOrDefault(p => p.ProductId == id);
            return View(product);
        }

        // DELETE POST
        [HttpPost]
        [ActionName("Delete")]
        public IActionResult DeleteConfirm(int id)
        {
            var product = products.FirstOrDefault(p => p.ProductId == id);

            if (product != null)
            {
                products.Remove(product);
            }

            return RedirectToAction("Index");
        }
    }
}