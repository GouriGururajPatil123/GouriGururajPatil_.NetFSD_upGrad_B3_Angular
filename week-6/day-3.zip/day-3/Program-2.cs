﻿/* Problem: 2- OCP – Open Closed Principle
Scenario: Discount Calculation System
An e-commerce system calculates discounts for different customer types:
•	Regular Customer
•	Premium Customer
•	VIP Customer
The system should allow adding new discount types without modifying existing code.

Requirements:
1.	Create an abstract class or interface:
IDiscountStrategy
2.	Implement discount classes:
•	RegularCustomerDiscount
•	PremiumCustomerDiscount
•	VipCustomerDiscount
3.	Each class should implement a method:
CalculateDiscount(double amount)
Technical Constraints:
•	Use interface or abstract class
•	Existing classes should not be modified when adding new discounts
•	Follow Open for Extension, Closed for Modification
Expectations:
	Students should implement:
•	IDiscountStrategy
•	3 Discount Classes
•	A class that calculates the final price

Program Flow Diagram:
	 
Learning Outcome:
Students will understand:
•	Extending functionality without modifying existing code
•	Use of interfaces and polymorphism
•	Real-world use of Strategy Pattern
*/

using System;

// 1. Interface (Contract)
public interface IDiscountStrategy
{
    double CalculateDiscount(double amount);
}

// 2. Regular Customer Discount
public class RegularCustomerDiscount : IDiscountStrategy
{
    public double CalculateDiscount(double amount)
    {
        return amount * 0.05; // 5% discount
    }
}

// 3. Premium Customer Discount
public class PremiumCustomerDiscount : IDiscountStrategy
{
    public double CalculateDiscount(double amount)
    {
        return amount * 0.10; // 10% discount
    }
}

// 4. VIP Customer Discount
public class VipCustomerDiscount : IDiscountStrategy
{
    public double CalculateDiscount(double amount)
    {
        return amount * 0.20; // 20% discount
    }
}

// 5. Discount Calculator (Uses Strategy)
public class DiscountCalculator
{
    public double GetFinalAmount(double amount, IDiscountStrategy discountStrategy)
    {
        double discount = discountStrategy.CalculateDiscount(amount);
        return amount - discount;
    }
}

// Main Program
class Program
{
    static void Main(string[] args)
    {
        DiscountCalculator calculator = new DiscountCalculator();

        double amount = 1000;

        // Choose discount type
        IDiscountStrategy regular = new RegularCustomerDiscount();
        IDiscountStrategy premium = new PremiumCustomerDiscount();
        IDiscountStrategy vip = new VipCustomerDiscount();

        Console.WriteLine("Regular Customer Final Price: " +
            calculator.GetFinalAmount(amount, regular));

        Console.WriteLine("Premium Customer Final Price: " +
            calculator.GetFinalAmount(amount, premium));

        Console.WriteLine("VIP Customer Final Price: " +
            calculator.GetFinalAmount(amount, vip));
    }
}