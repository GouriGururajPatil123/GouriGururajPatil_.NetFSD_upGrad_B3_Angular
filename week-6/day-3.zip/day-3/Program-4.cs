﻿/* Problem 4- ISP – Interface Segregation Principle
Scenario: Office Printer System
An office has different machines:
•	Basic Printer (Print only)
•	Advanced Printer (Print + Scan + Fax)
If we create a single large interface, basic printers will be forced to implement unnecessary methods.
The task is to split the interface into smaller interfaces.

Requirements:
Create the following interfaces:
•	IPrinter
•	IScanner
•	IFax
Classes:
•	BasicPrinter → Print only
•	AdvancedPrinter → Print + Scan + Fax

Technical Constraints:
•	Follow Interface Segregation Principle
•	Classes should not implement unnecessary methods
Expectations:
Students should implement:
Interfaces
•	IPrinter
•	IScanner
•	IFax
Classes
•	BasicPrinter
•	AdvancedPrinter
Program Flow Diagram:
 

Learning Outcome:
Students will learn:
•	Why large interfaces are bad
•	How to design small focused interfaces
•	Better maintainability and flexibility

*/

using System;

// 1. Small Interfaces

public interface IPrinter
{
    void Print();
}

public interface IScanner
{
    void Scan();
}

public interface IFax
{
    void Fax();
}

// 2. Basic Printer (Only Print)

public class BasicPrinter : IPrinter
{
    public void Print()
    {
        Console.WriteLine("Basic Printer: Printing document...");
    }
}

// 3. Advanced Printer (Print + Scan + Fax)

public class AdvancedPrinter : IPrinter, IScanner, IFax
{
    public void Print()
    {
        Console.WriteLine("Advanced Printer: Printing document...");
    }

    public void Scan()
    {
        Console.WriteLine("Advanced Printer: Scanning document...");
    }

    public void Fax()
    {
        Console.WriteLine("Advanced Printer: Sending fax...");
    }
}

// Main Program
class Program
{
    static void Main(string[] args)
    {
        // Basic Printer
        IPrinter basic = new BasicPrinter();
        basic.Print();

        Console.WriteLine();

        // Advanced Printer
        AdvancedPrinter advanced = new AdvancedPrinter();
        advanced.Print();
        advanced.Scan();
        advanced.Fax();
    }
}

