﻿/*Problem: 1- SRP – Single Responsibility Principle
Scenario: Student Report Generator
A training institute like Codempower Academy maintains student information and generates performance reports. Currently, one class performs student data storage and report generation, which makes the code difficult to maintain.
Requirements:
1.Create a Student class with properties:
•	StudentId
•	StudentName
•	Marks
2.Create a class responsible for managing student data.
3.Create a separate class responsible for generating reports.
 4.The report should display:

Security Requirements (Secure Coding Practices)
Students must implement the following security measures:
Technical Constraints:
•	Use C# (.NET Console Application).
•	Each class must have only one responsibility.
•	Do not mix data storage and report generation logic in the same class.
Expectations:
Students should implement at least three classes:
•	Student
•	StudentRepository
•	ReportGenerator
Program Flow Diagram
 

Learning Outcome:
Students will learn:
•	Meaning of Single Responsibility Principle
•	How to separate responsibilities
•	How SRP improves maintainability and testing
*/

using System;
using System.Collections.Generic;

// 1. Student Class (Only Data)
public class Student
{
    public int StudentId { get; set; }
    public string StudentName { get; set; }
    public int Marks { get; set; }
}

// 2. StudentRepository (Only Data Management)
public class StudentRepository
{
    private List<Student> students = new List<Student>();

    public void AddStudent(Student student)
    {
        students.Add(student);
    }

    public List<Student> GetAllStudents()
    {
        return students;
    }
}

// 3. ReportGenerator (Only Report Logic)
public class ReportGenerator
{
    public void GenerateReport(List<Student> students)
    {
        Console.WriteLine("\n----- Student Report -----");

        foreach (var student in students)
        {
            string grade = GetGrade(student.Marks);

            Console.WriteLine($"ID: {student.StudentId}");
            Console.WriteLine($"Name: {student.StudentName}");
            Console.WriteLine($"Marks: {student.Marks}");
            Console.WriteLine($"Grade: {grade}");
            Console.WriteLine("------------------------");
        }
    }

    private string GetGrade(int marks)
    {
        if (marks >= 90) return "A";
        else if (marks >= 75) return "B";
        else if (marks >= 50) return "C";
        else return "Fail";
    }
}

// Main Program
class Program
{
    static void Main(string[] args)
    {
        StudentRepository repo = new StudentRepository();
        ReportGenerator report = new ReportGenerator();

        // Adding Students
        repo.AddStudent(new Student { StudentId = 1, StudentName = "Gouri", Marks = 85 });
        repo.AddStudent(new Student { StudentId = 2, StudentName = "Rahul", Marks = 45 });
        repo.AddStudent(new Student { StudentId = 3, StudentName = "Sneha", Marks = 92 });

        // Generate Report
        List<Student> students = repo.GetAllStudents();
        report.GenerateReport(students);
    }
}