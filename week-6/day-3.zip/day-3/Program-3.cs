﻿/* Problem 3- LSP – Liskov Substitution Principle
Scenario: Shape Area Calculator
A graphics application calculates the area of different shapes.
Any derived class should be able to replace the base class without breaking functionality.
Requirements:
1.	Create a base class or interface:
•	Shape
2.	Derived classes:
•	Rectangle
•	Circle
3.	Each shape should implement:
•	CalculateArea()
4.	A method should accept Shape object and calculate area.
Technical Constraints:
•	Use method overriding
•	Derived classes must not break base class behavior
Expectations:
Students should demonstrate that the program works correctly when:
•	Rectangle object is used
•	Circle object is used

Program Flow Diagram:
 
Learning Outcome:
Students will learn:
•	Meaning of substitutability
•	Importance of correct inheritance
•	How polymorphism supports LSP

*/

using System;
using System.Collections.Generic;

// Base Class (Abstraction)
public abstract class Shape
{
    public abstract double CalculateArea();
}

// Rectangle Class
public class Rectangle : Shape
{
    public double Length { get; set; }
    public double Width { get; set; }

    public Rectangle(double length, double width)
    {
        Length = length;
        Width = width;
    }

    public override double CalculateArea()
    {
        return Length * Width;
    }
}

// Circle Class
public class Circle : Shape
{
    public double Radius { get; set; }

    public Circle(double radius)
    {
        Radius = radius;
    }

    public override double CalculateArea()
    {
        return Math.PI * Radius * Radius;
    }
}

// (Optional Extension - Shows OCP)
public class Triangle : Shape
{
    public double BaseValue { get; set; }
    public double Height { get; set; }

    public Triangle(double b, double h)
    {
        BaseValue = b;
        Height = h;
    }

    public override double CalculateArea()
    {
        return 0.5 * BaseValue * Height;
    }
}

// Main Program
class Program
{
    static void Main(string[] args)
    {
        List<Shape> shapes = new List<Shape>();

        while (true)
        {
            Console.WriteLine("\n--- Shape Area Calculator ---");
            Console.WriteLine("1. Rectangle");
            Console.WriteLine("2. Circle");
            Console.WriteLine("3. Triangle");
            Console.WriteLine("4. Show All Areas");
            Console.WriteLine("5. Exit");
            Console.Write("Enter choice: ");

            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter Length: ");
                    double length = double.Parse(Console.ReadLine());

                    Console.Write("Enter Width: ");
                    double width = double.Parse(Console.ReadLine());

                    shapes.Add(new Rectangle(length, width));
                    break;

                case 2:
                    Console.Write("Enter Radius: ");
                    double radius = double.Parse(Console.ReadLine());

                    shapes.Add(new Circle(radius));
                    break;

                case 3:
                    Console.Write("Enter Base: ");
                    double b = double.Parse(Console.ReadLine());

                    Console.Write("Enter Height: ");
                    double h = double.Parse(Console.ReadLine());

                    shapes.Add(new Triangle(b, h));
                    break;

                case 4:
                    Console.WriteLine("\n--- Areas ---");
                    foreach (var shape in shapes)
                    {
                        Console.WriteLine($"Area: {shape.CalculateArea()}");
                    }
                    break;

                case 5:
                    return;

                default:
                    Console.WriteLine("Invalid choice!");
                    break;
            }
        }
    }
}