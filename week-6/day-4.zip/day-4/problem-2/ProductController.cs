﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class ProductController : Controller
    {
        // Sample data
        static List<Product> products = new List<Product>()
        {
            new Product { ProductId = 1, ProductName = "Laptop", Price = 50000 },
            new Product { ProductId = 2, ProductName = "Mobile", Price = 20000 },
            new Product { ProductId = 3, ProductName = "Headphones", Price = 2000 }
        };

        public IActionResult Index()
        {
            return View(products); 
        }

        public IActionResult Details(int id)
        {
            var product = products.FirstOrDefault(p => p.ProductId == id);

            if (product == null)
                return NotFound();

            return View(product);
        }
    }
}