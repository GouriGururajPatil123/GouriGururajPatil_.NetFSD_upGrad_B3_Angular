﻿/*Level-2 Problem 4: Asynchronous Order Processing System
Scenario:
 An e-commerce system processes customer orders. Each order requires multiple steps such as payment verification, inventory check, and order confirmation. These steps involve delays and should be handled asynchronously.
 
Requirements:
 - Create asynchronous methods:
   - VerifyPaymentAsync()
   - CheckInventoryAsync()
   - ConfirmOrderAsync()
 - Simulate processing delays using Task.Delay().
 - Execute steps asynchronously while maintaining the logical order of operations.
Technical Constraints:
 - Use async and await.
 - Use Task-based asynchronous methods.
 - Implement using a console application.
 
Expectations:
 - Each processing step should run asynchronously.
 - The program should display messages indicating the progress of order processing.
 
Learning Outcome:
 Students will understand how to design real-world workflows using asynchronous methods with async/await.
 */
using System;
using System.Threading.Tasks;

namespace AsyncOrderProcessing
{
    class Program
    {
        // Step 1: Verify Payment
        public static async Task VerifyPaymentAsync()
        {
            Console.WriteLine("Payment Verification Started...");
            await Task.Delay(2000); // Simulate delay
            Console.WriteLine("Payment Verified.");
        }

        // Step 2: Check Inventory
        public static async Task CheckInventoryAsync()
        {
            Console.WriteLine("Inventory Check Started...");
            await Task.Delay(3000); // Simulate delay
            Console.WriteLine("Inventory Available.");
        }

        // Step 3: Confirm Order
        public static async Task ConfirmOrderAsync()
        {
            Console.WriteLine("Order Confirmation Started...");
            await Task.Delay(1500); // Simulate delay
            Console.WriteLine("Order Confirmed Successfully!");
        }

        static async Task Main(string[] args)
        {
            Console.WriteLine("Order Processing Started...\n");

            // Execute steps in logical sequence
            await VerifyPaymentAsync();
            await CheckInventoryAsync();
            await ConfirmOrderAsync();

            Console.WriteLine("\nOrder Processing Completed!");
        }
    }
}
