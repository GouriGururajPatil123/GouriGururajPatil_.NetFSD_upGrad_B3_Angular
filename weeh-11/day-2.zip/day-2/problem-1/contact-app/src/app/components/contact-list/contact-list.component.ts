import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactService } from '../../services/contact.service';
import { Contact } from '../../models/contact';

@Component({
  selector: 'app-contact-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './contact-list.component.html'
})
export class ContactListComponent {

  contacts: Contact[] = [];

  constructor(private service: ContactService) {
    this.contacts = this.service.getContacts();
  }

  selectContact(contact: Contact) {
    this.service.setSelectedContact(contact);
  }
}