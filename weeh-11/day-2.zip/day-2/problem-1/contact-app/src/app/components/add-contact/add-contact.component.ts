import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ContactService } from '../../services/contact.service';
import { Contact } from '../../models/contact';

@Component({
  selector: 'app-add-contact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-contact.component.html'
})
export class AddContactComponent {

  contact: Contact = {
    id: 0,
    name: '',
    email: '',
    phone: ''
  };

  errorMessage: string = '';

  constructor(private service: ContactService) {}

  addContact() {

    // Validation 
    if (!this.contact.name || !this.contact.email || !this.contact.phone) {
      this.errorMessage = "Please fill all fields";
      return;
    }

    // clear error if valid
    this.errorMessage = '';

    // add contact to service
    this.service.addContact(this.contact);

    // reset form
    this.contact = {
      id: 0,
      name: '',
      email: '',
      phone: ''
    };
  }
}