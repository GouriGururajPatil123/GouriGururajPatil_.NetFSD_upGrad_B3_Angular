import { Routes } from '@angular/router';
import { ContactList } from './components/contact-list/contact-list';
import { AddContact } from './components/add-contact/contact-list';
import { ContactDetail } from './components/contact-detail/contact-list';

export const routes: Routes = [
  { path: '', redirectTo: 'contacts', pathMatch: 'full' },

  { path: 'contacts', component: ContactList },

  { path: 'add', component: AddContact },

  { path: 'detail', component: ContactDetail }
];