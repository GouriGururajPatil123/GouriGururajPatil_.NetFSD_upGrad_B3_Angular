import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactListComponent } from './components/contact-list/contact-list.component';
import { ContactDetailComponent } from './components/contact-detail/contact-detail.component';
import { AddContactComponent } from './components/add-contact/add-contact.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    ContactListComponent,
    AddContactComponent,
    ContactDetailComponent
  ],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App { }