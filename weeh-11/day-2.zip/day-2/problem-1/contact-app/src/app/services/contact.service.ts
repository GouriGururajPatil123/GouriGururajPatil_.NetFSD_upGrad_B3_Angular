import { Injectable } from '@angular/core';
import { Contact } from '../models/contact';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  private contacts: Contact[] = [
    { id: 1, name: 'John Doe', email: 'john@gmail.com', phone: '1234567890' },
    { id: 2, name: 'Jane Smith', email: 'jane@gmail.com', phone: '9876543210' }
  ];

  selectedContact?: Contact;

  getContacts(): Contact[] {
    return this.contacts;
  }

  addContact(contact: Contact): void {
    this.contacts.push(contact);
  }

  getContactById(id: number): Contact | undefined {
    return this.contacts.find(c => c.id === id);
  }

  setSelectedContact(contact: Contact) {
    this.selectedContact = contact;
  }

  getSelectedContact(): Contact | undefined {
    return this.selectedContact;
  }
}