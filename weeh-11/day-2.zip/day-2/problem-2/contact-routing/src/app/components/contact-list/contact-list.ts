import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ContactService } from '../../services/contact.service';
import { Contact } from '../../models/contact';

@Component({
  selector: 'app-contact-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './contact-list.html'
})
export class ContactList {

  contacts: Contact[] = [];   // ✅ FIX HERE

  constructor(private service: ContactService, private router: Router) {
    this.contacts = this.service.getContacts();
  }

  viewContact(id: number) {
    this.router.navigate(['/contact', id]);
  }
}