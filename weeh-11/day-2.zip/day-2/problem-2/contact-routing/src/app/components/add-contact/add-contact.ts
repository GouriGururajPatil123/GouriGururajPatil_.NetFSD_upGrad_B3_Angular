import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ContactService } from '../../services/contact.service';

@Component({
  selector: 'app-add-contact',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './add-contact.html'
})
export class AddContact {

  contact = { id: 0, name: '', email: '', phone: '' };

  constructor(private service: ContactService) {}

  addContact(form: any) {
    if (form.invalid) return;

    this.service.addContact(this.contact);

    alert('Contact Added Successfully');

    this.contact = { id: 0, name: '', email: '', phone: '' };

    form.resetForm();
  }
}