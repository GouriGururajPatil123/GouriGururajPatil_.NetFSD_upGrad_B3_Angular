import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ContactService } from '../../services/contact.service';

@Component({
  selector: 'app-contact-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './contact-detail.html'
})
export class ContactDetail {

  contact: any;

  constructor(private route: ActivatedRoute, private service: ContactService) {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.contact = this.service.getContactById(id);
  }
}