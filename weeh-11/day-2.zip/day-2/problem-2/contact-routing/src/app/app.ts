import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink],
  template: `
    <h1>Contact Routing App</h1>

    <nav>
      <a routerLink="/contacts">Contacts</a> |
      <a routerLink="/add-contact">Add Contact</a>
    </nav>

    <router-outlet></router-outlet>
  `,
  styles: [`
    h1 {
      text-align: center;
    }

    nav {
      text-align: center;
      margin-bottom: 20px;
    }

    nav a {
      margin: 10px;
      text-decoration: none;
      font-weight: bold;
    }
  `]
})
export class App {}