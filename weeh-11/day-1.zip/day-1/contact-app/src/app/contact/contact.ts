import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { PhoneFormatPipe } from '../phone-format-pipe';
import { StatusPipe } from '../status-pipe';
import { SearchPipe } from '../search-pipe';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    PhoneFormatPipe,
    StatusPipe,
    SearchPipe
  ],
  templateUrl: './contact.html',
  styleUrls: ['./contact.css']
})
export class Contact {

  searchText: string = '';

  contacts: any[] = [
    { name: 'scott', email: 'scott@gmail.com', phone: '9876543210', status: true },
    { name: 'abron', email: 'abron@gmail.com', phone: '9876543211', status: false },
    { name: 'smith', email: 'smith@gmail.com', phone: '9876543212', status: true },
    { name: 'james', email: 'james@gmail.com', phone: '9876543213', status: false },
    { name: 'adam', email: 'adam@gmail.com', phone: '9876543214', status: true }
  ];

  toggleStatus(contact: any) {
    contact.status = !contact.status;
  }
}