import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search',
  standalone: true,
  pure: false
})
export class SearchPipe implements PipeTransform {

  transform(items: any[] | null, searchText: string): any[] {

    if (!items) return [];
    if (!searchText) return items;

    searchText = searchText.toLowerCase();

    return items.filter(c =>
      c.name.toLowerCase().includes(searchText) ||
      c.email.toLowerCase().includes(searchText)
    );
  }
}