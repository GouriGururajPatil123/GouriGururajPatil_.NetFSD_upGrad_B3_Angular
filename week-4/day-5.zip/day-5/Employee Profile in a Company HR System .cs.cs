﻿using System;

namespace HRSystem
{
    public class Employee
    {
        // Private Fields (Data Hiding)
        private string _fullName;
        private int _age;
        private decimal _salary;

        // Readonly Employee ID
        public string EmployeeId { get; }

        // FullName Property
        public string FullName
        {
            get => _fullName;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Full name cannot be empty or whitespace.");
                //trim()==remoce extea spaces from beginning aand end of a string
                _fullName = value.Trim();
            }
        }

        // Age Property
        public int Age
        {
            get => _age;
            set
            {
                if (value < 18 || value > 80)
                    throw new ArgumentException("Age must be between 18 and 80.");

                _age = value;
            }
        }

        // Salary Property
        public decimal Salary
        {
            get => _salary;
            private set
            {
                if (value < 1000)
                    throw new ArgumentException("Salary cannot be less than 1000.");

                _salary = value;
            }
        }

        // Constructor
        public Employee(string fullName, decimal startingSalary, int age, string employeeId = null)
        {
            // Assign Employee ID (auto generate if not provided)

            //if the user will not provide emp id, the system will auttomatically generat one
            EmployeeId = string.IsNullOrWhiteSpace(employeeId)
                ? "E" + Guid.NewGuid().ToString().Substring(0, 6)
                : employeeId;

            // Use property setters for validation
            FullName = fullName;
            Age = age;
            Salary = startingSalary;
        }

        // Give Raise Method
        public void GiveRaise(decimal percentage)
        {
            if (percentage <= 0 || percentage > 30)
                throw new ArgumentException("Raise percentage must be between 0 and 30.");

            decimal increase = Salary * percentage / 100;
            Salary += increase;

            Console.WriteLine($"Salary increased by {percentage}%.");
            Console.WriteLine($"New Salary: {Salary}");
        }

        // Deduct Penalty Method
        public bool DeductPenalty(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentException("Penalty amount must be greater than 0.");

            if (Salary - amount < 1000)
            {
                Console.WriteLine("Penalty rejected. Salary cannot go below 1000.");
                return false;
            }

            Salary -= amount;
            Console.WriteLine($"Penalty deducted: {amount}");
            Console.WriteLine($"New Salary: {Salary}");
            return true;
        }
    }

    // Test Program
    class Program
    {
        static void Main()
        {
            try
            {
                Employee emp = new Employee("Marko Horvat", 4500m, 35);

                Console.WriteLine("Employee Created");
                Console.WriteLine("ID: " + emp.EmployeeId);
                Console.WriteLine("Name: " + emp.FullName);
                Console.WriteLine("Age: " + emp.Age);
                Console.WriteLine("Salary: " + emp.Salary);

                Console.WriteLine("\n--- Give Raise ---");
                emp.GiveRaise(15);

                Console.WriteLine("\n--- Deduct Penalty ---");
                emp.DeductPenalty(500);

                Console.WriteLine("\n--- Update Name ---");
                emp.FullName = "Marko Horvat Jr.";
                Console.WriteLine(emp.FullName);

                // Invalid Example
                // emp.Salary = 800;  // Not possible (private set)
                // emp.Age = 10;      // Throws exception

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}