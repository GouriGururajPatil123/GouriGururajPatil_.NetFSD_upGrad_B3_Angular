﻿CREATE DATABASE SalesDB;
USE SalesDB;

--problem -1 

--Level-2 Problem 1: Stored Procedures and User-Defined Functions
--Scenario
--The company requires reusable database logic to generate reports such as total sales per store and discounted order totals.
--📌 Requirements 
-- Create a stored procedure to generate total sales amount per store.
--- Create a stored procedure to retrieve orders by date range.
-- Create a scalar function to calculate total price after discount.
-- Create a table-valued function to return top 5 selling products.
--🛠️ Technical Constraints 
-- Use input parameters in stored procedures.
-- Handle NULL values properly.
-- Ensure optimized queries inside procedures.
-- Follow proper naming conventions.

-- Stores Table
CREATE TABLE Stores (
    store_id INT PRIMARY KEY,
    store_name VARCHAR(100)
);

-- Products Table
CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    price DECIMAL(10,2)
);

-- Orders Table
CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    store_id INT,
    order_date DATE,
    FOREIGN KEY (store_id) REFERENCES Stores(store_id)
);

-- Order Items Table
CREATE TABLE Order_Items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    discount DECIMAL(5,2),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

INSERT INTO Stores VALUES
(1,'Bangalore Store'),
(2,'Mumbai Store');

INSERT INTO Products VALUES
(101,'Laptop',50000),
(102,'Mobile',20000),
(103,'Tablet',15000),
(104,'Headphones',3000),
(105,'Keyboard',1500),
(106,'Mouse',800);

INSERT INTO Orders VALUES
(1,1,'2024-02-01'),
(2,1,'2024-02-10'),
(3,2,'2024-02-15');

INSERT INTO Order_Items VALUES
(1,1,101,2,10),
(2,1,102,1,5),
(3,2,103,3,8),
(4,3,101,1,7),
(5,3,104,5,0),
(6,3,105,4,3);

--Stored Procedure – Total Sales Amount Per Store

CREATE PROCEDURE sp_GetTotalSalesByStore
    @store_id INT
AS
BEGIN
    SELECT 
        s.store_name,
        SUM(ISNULL(p.price * oi.quantity,0)) AS Total_Sales
    FROM Stores s
    JOIN Orders o ON s.store_id = o.store_id
    JOIN Order_Items oi ON o.order_id = oi.order_id
    JOIN Products p ON oi.product_id = p.product_id
    WHERE s.store_id = @store_id
    GROUP BY s.store_name;
END

EXEC sp_GetTotalSalesByStore 1;

--Stored Procedure – Retrieve Orders by Date Range

CREATE PROCEDURE sp_GetOrdersByDateRange
    @start_date DATE,
    @end_date DATE
AS
BEGIN
    SELECT 
        order_id,
        store_id,
        order_date
    FROM Orders
    WHERE order_date BETWEEN @start_date AND @end_date;
END

EXEC sp_GetOrdersByDateRange '2024-02-01','2024-02-28';

--Scalar Function – Calculate Total Price After Discount

CREATE FUNCTION fn_CalculateDiscountPrice
(
    @price DECIMAL(10,2),
    @discount DECIMAL(5,2)
)
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @final_price DECIMAL(10,2);

    SET @price = ISNULL(@price,0);
    SET @discount = ISNULL(@discount,0);

    SET @final_price = @price - (@price * @discount / 100);

    RETURN @final_price;
END

SELECT 
product_name,
price,
dbo.fn_CalculateDiscountPrice(price,10) AS DiscountedPrice
FROM Products;

--Table-Valued Function – Top 5 Selling Products

CREATE FUNCTION fn_Top5SellingProducts()
RETURNS TABLE
AS
RETURN
(
    SELECT TOP 5
        p.product_name,
        SUM(oi.quantity) AS Total_Sold
    FROM Order_Items oi
    JOIN Products p 
        ON oi.product_id = p.product_id
    GROUP BY p.product_name
    ORDER BY Total_Sold DESC
);

SELECT * FROM dbo.fn_Top5SellingProducts();


--problem - 2

--Level-2 Problem 2: Stock Auto-Update Trigger
--Scenario
--Whenever a new record is inserted into order_items, the stock quantity in the stocks table must automatically decrease based on the ordered quantity.
--📌 Requirements 
-- Create an AFTER INSERT trigger on order_items.
-- Reduce the corresponding quantity in stocks table.
-- Prevent stock from becoming negative.
-- If stock is insufficient, rollback the transaction with a custom error message.
--🛠️ Technical Constraints 
-- Use AFTER trigger.
-- Use TRY…CATCH block inside the trigger.
-- Use RAISERROR or THROW for custom error messages.
-- Use ROLLBACK if stock is insufficient.

IF OBJECT_ID('order_items','U') IS NOT NULL DROP TABLE order_items;
IF OBJECT_ID('orders','U') IS NOT NULL DROP TABLE orders;
IF OBJECT_ID('stocks','U') IS NOT NULL DROP TABLE stocks;
IF OBJECT_ID('products','U') IS NOT NULL DROP TABLE products;

--problem - 3

--Level-2 Problem 3: Order Status Validation Trigger
--Scenario
--Before updating order_status in orders table, ensure that shipped_date is not NULL when status is set to Completed (4).
--📌 Requirements 
-- Create an AFTER UPDATE trigger on orders.
-- Validate that shipped_date is NOT NULL when order_status = 4.
-- Prevent update if condition fails.
--🛠️ Technical Constraints 
-- Use AFTER UPDATE trigger.
-- Use inserted logical table for validation.
-- Use TRY…CATCH with custom error message.
-- Rollback transaction if validation fails.

--problem - 4

--Level-2 Problem 3: Cursor-Based Revenue Calculation
--Scenario
--Management wants a detailed revenue calculation per store by iterating through completed orders and calculating total revenue including discounts.
--📌 Requirements 
-- Use a cursor to iterate through completed orders (order_status = 4).
-- Calculate total revenue per order using order_items.
-- Store computed revenue in a temporary table.
-- Display store-wise revenue summary.
--🛠️ Technical Constraints 
-- Use CURSOR for row-by-row processing.
-- Use TRY…CATCH for error handling.
-- Use explicit BEGIN TRANSACTION and COMMIT.
-- Use ROLLBACK in case of failure.






