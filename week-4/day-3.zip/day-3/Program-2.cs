﻿/*Level-1 Problem 2: Simple Calculator Using Switch
Scenario
Create a simple calculator application that performs basic arithmetic operations.
Requirements
• Accept two numbers from user.
• Accept operator (+, -, *, /).
• Use switch statement to perform operation.
• Display result.
Technical Constraints
• Use int or double data types.
• Use switch-case statement.
• Handle division by zero.
Sample Input
Enter First Number: 10
Enter Second Number: 5
Enter Operator: *
Sample Output
Result: 50
   */

namespace ConsoleApp10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the 1st number : ");
            int x = int.Parse(Console.ReadLine());

            Console.WriteLine("enter the 2nd number :");
            int y = int.Parse(Console.ReadLine());

            Console.WriteLine("enter the operator [+ , - , * , / ] : ");
            char op = char.Parse(Console.ReadLine());

            int z = 0;

            //switch case
            switch (op)
            {
                case '+':
                    z = x + y;
                    break;

                case '-':
                    z = x - y;
                    break;

                case '*':
                    z = x * y;
                    break;

                case '/':
                    z = x / y;
                    break;

                default:
                    Console.WriteLine("invalid opeartion.");
                    Console.ReadLine();
                    return;
                     
            }


            Console.WriteLine("Final result :" +z);

            Console.ReadLine();



        }
    }
}
