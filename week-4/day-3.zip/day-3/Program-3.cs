﻿/*   Level-2 Problem 1: Employee Bonus Calculator
Scenario
Develop a console application that calculates employee bonus based on salary and years of experience.
Requirements
• Accept employee name, salary and years of experience.
• Use if-else and conditional operator.
• Bonus rules:
   - Experience < 2 years: 5% bonus
   - 2-5 years: 10% bonus
   - >5 years: 15% bonus
• Display final salary after bonus.
Technical Constraints
• Use double for salary.
• Use if-else and ternary operator.
• Use proper formatting for currency output.
Sample Input
Enter Name: Aisha
Enter Salary: 50000
Enter Experience: 4
Sample Output
Employee: Aisha
Bonus: 5000
Final Salary: 55000
   */

namespace EmployeeBonusCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the emp name :");
            string name = Console.ReadLine();

            Console.WriteLine("enter the  emp salary :");
            double salary = double.Parse(Console.ReadLine());

            Console.WriteLine("enter the experience (yaer) :");
            int experience=int.Parse(Console.ReadLine());

            double bonusPercentage;

            if (experience < 2)
            {
                bonusPercentage = 0.05;
            }
            else if (experience <= 5)
            {
                bonusPercentage = 0.10;
            }
            else
            {
                bonusPercentage = 0.15;
            }

            // Calculate bonus using ternary operator
            double bonus = salary > 0 ? salary * bonusPercentage : 0;

            double finalSalary = salary + bonus;

            Console.WriteLine("Employee name :" + name);
            Console.WriteLine("Bonus: " + bonus);
            Console.WriteLine("Final Salary: " + finalSalary);

            Console.ReadLine();
        }
    }
}
