﻿/* Assignment
 ~~~~~~~~~~~~~~
  
 Write  a  C# program to process product details using object oriented programming.
 
•	Class should contain private variables:  productId, productName, unitPrice, qty.
•	Constructor should allow productId as parameter
•	 Create properties for all private variables. Property Names :   ProductId, ProductName, UnitPrice, Quantity
•	ProductId – should be readonly property
•	ShowDetails()  method to display all the details along with total amount. */
using System;

namespace ProductApp
{
    // Product class
    class Product
    {
        // Private fields
        private int _productId;
        private string _productName;
        private double _unitPrice;
        private int _qty;

        // Constructor: accepts productId
        public Product(int productId)
        {
            _productId = productId;
            _productName = string.Empty;
            _unitPrice = 0;
            _qty = 0;
        }

        // Properties
        public int ProductId
        {
            get { return _productId; } // Readonly
        }

        public string ProductName
        {
            get { return _productName; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    _productName = value;
                else
                    Console.WriteLine("Product name cannot be empty!");
            }
        }

        public double UnitPrice
        {
            get { return _unitPrice; }
            set
            {
                if (value >= 0)
                    _unitPrice = value;
                else
                    Console.WriteLine("Unit price cannot be negative!");
            }
        }

        public int Quantity
        {
            get { return _qty; }
            set
            {
                if (value >= 0)
                    _qty = value;
                else
                    Console.WriteLine("Quantity cannot be negative!");
            }
        }

        // Method to display product details
        public void ShowDetails()
        {
            double totalAmount = _unitPrice * _qty;
            Console.WriteLine("----- Product Details -----");
            Console.WriteLine($"Product ID   : {_productId}");
            Console.WriteLine($"Product Name : {_productName}");
            Console.WriteLine($"Unit Price   : {_unitPrice:C}");
            Console.WriteLine($"Quantity     : {_qty}");
            Console.WriteLine($"Total Amount : {totalAmount:C}");
            Console.WriteLine("----------------------------");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            // Create product object with ID
            Product product = new Product(101);

            // Set product details using properties
            product.ProductName = "Wireless Mouse";
            product.UnitPrice = 799.50;
            product.Quantity = 5;

            // Display product details
            product.ShowDetails();

            Console.ReadLine();
        }
    }
}
