﻿/* Level-1 Problem 1: Simple Calculator Using Methods
Scenario:
A small retail shop wants a simple calculator application to perform addition and subtraction operations using reusable methods.
Requirements:
1. Create a class named Calculator.
2. Create methods Add(int a, int b) and Subtract(int a, int b).
3. Each method should return the result.
4. In Main(), create an object and call the methods.
5. Display the output.
Technical Constraints:
1. Use method parameters and return types properly.
2. Use appropriate access modifiers.
3. No global variables allowed.
Expectations:
Proper method definition, object creation, and method invocation.
Learning Outcome:
Understand functions, parameters, return types, classes, and objects.
Sample Input: 10 5
Sample Output: Addition = 15, Subtraction = 5
*/

using System;

namespace ConsoleApp
{
    // Calculator class
    class Calculator
    {
        // Method for Addition
        public int Add(int a, int b)
        {
            return a + b;
        }

        // Method for Subtraction
        public int Subtract(int a, int b)
        {
            return a - b;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.Write("Enter first number: ");
            num1 = int.Parse(Console.ReadLine());

            Console.Write("Enter second number: ");
            num2 = int.Parse(Console.ReadLine());

            // Create object of Calculator class
            Calculator calc = new Calculator();

            // Call methods
            int addition = calc.Add(num1, num2);
            int subtraction = calc.Subtract(num1, num2);

            // Display results
            Console.WriteLine($"Addition = {addition}");
            Console.WriteLine($"Subtraction = {subtraction}");

            Console.ReadLine();
        }
    }
}