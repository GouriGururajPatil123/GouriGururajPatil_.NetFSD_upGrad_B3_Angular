﻿/* Level-1 Problem 2: Student Grade Calculator
Scenario:
A school wants to calculate the average marks of a student using a class-based approach.
Requirements:
1. Create a class Student.
2. Create method CalculateAverage(int m1, int m2, int m3).
3. Return the average marks.
4. Display grade based on average.
Technical Constraints:
1. Use return type double for average.
2. Avoid hard-coded values.
Expectations:
Clear separation of logic inside methods.
Learning Outcome:
Learn method creation, return values, and basic OOP concepts.
Sample Input: 
80 70 90
Sample Output: 
Average = 80, Grade = A */

using System;

namespace ConsoleApp
{
    // Student class
    class Student
    {
        // Method to calculate average
        public double CalculateAverage(int m1, int m2, int m3)
        {
            double avg = (m1 + m2 + m3) / 3.0;
            return avg;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            int m1, m2, m3;

            Console.Write("Enter marks 1: ");
            m1 = int.Parse(Console.ReadLine());

            Console.Write("Enter marks 2: ");
            m2 = int.Parse(Console.ReadLine());

            Console.Write("Enter marks 3: ");
            m3 = int.Parse(Console.ReadLine());

            // Create Student object
            Student s = new Student();

            // Call method
            double average = s.CalculateAverage(m1, m2, m3);

            // Determine grade
            char grade;

            if (average >= 80)
                grade = 'A';
            else if (average >= 60)
                grade = 'B';
            else if (average >= 50)
                grade = 'C';
            else
                grade = 'F';

            // Display result
            Console.WriteLine($"Average = {average}, Grade = {grade}");

            Console.ReadLine();
        }
    }
}
