﻿using System.ComponentModel.DataAnnotations;

public class Contact
{
    public int ContactId { get; set; }

    [Required(ErrorMessage = "Name is required")]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Invalid email format")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Phone is required")]
    [StringLength(10, MinimumLength = 10, ErrorMessage = "Phone must be 10 digits")]
    public string Phone { get; set; } = string.Empty;
}