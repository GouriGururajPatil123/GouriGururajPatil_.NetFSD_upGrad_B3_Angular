﻿using Microsoft.AspNetCore.Mvc;
using ContactService.Data;
using ContactService.Models;
using ContactService.Services;

namespace ContactService.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly JwtService _jwt;

    public AuthController(AppDbContext context, JwtService jwt)
    {
        _context = context;
        _jwt = jwt;
    }

    //REGISTER
    [HttpPost("register")]
    public IActionResult Register(UserInfo user)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // Check if user already exists
        var existingUser = _context.Users.FirstOrDefault(x => x.EmailId == user.EmailId);
        if (existingUser != null)
            return BadRequest("User already exists");

        _context.Users.Add(user);
        _context.SaveChanges();

        return Ok(new { message = "User Registered Successfully" });
    }

    // LOGIN
    [HttpPost("login")]
    public IActionResult Login(LoginRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var user = _context.Users.FirstOrDefault(x =>
            x.EmailId == request.Email && x.Password == request.Password);

        if (user == null)
            return Unauthorized(new { message = "Invalid email or password" });

        var token = _jwt.GenerateToken(user);

        return Ok(new
        {
            message = "Login Successful",
            token = token
        });
    }
}