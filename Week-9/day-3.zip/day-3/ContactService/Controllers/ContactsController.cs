﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using ContactService.Data;
using ContactService.Models;

namespace ContactService.Models;

[ApiController]
[Route("api/[controller]")]
[Authorize] //All endpoints require login
public class ContactController : ControllerBase
{
    private readonly AppDbContext _context;

    public ContactController(AppDbContext context)
    {
        _context = context;
    }

    // GET ALL
    [HttpGet]
    public IActionResult GetAll()
    {
        var contacts = _context.Contacts.ToList();
        return Ok(contacts);
    }

    // GET BY ID
    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var contact = _context.Contacts.Find(id);

        if (contact == null)
            return NotFound(new { message = "Contact not found" });

        return Ok(contact);
    }

    // CREATE (ADMIN ONLY)
    [HttpPost]
    [Authorize(Roles = "Admin")]
    public IActionResult Create(Contact contact)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _context.Contacts.Add(contact);
        _context.SaveChanges();

        return Ok(new
        {
            message = "Contact created successfully",
            data = contact
        });
    }

    // UPDATE (ADMIN ONLY)
    [HttpPut("{id}")]
    [Authorize(Roles = "Admin")]
    public IActionResult Update(int id, Contact updatedContact)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var contact = _context.Contacts.Find(id);

        if (contact == null)
            return NotFound(new { message = "Contact not found" });

        contact.Name = updatedContact.Name;
        contact.Email = updatedContact.Email;
        contact.Phone = updatedContact.Phone;

        _context.SaveChanges();

        return Ok(new
        {
            message = "Contact updated successfully",
            data = contact
        });
    }

    // DELETE (ADMIN ONLY)
    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    public IActionResult Delete(int id)
    {
        var contact = _context.Contacts.Find(id);

        if (contact == null)
            return NotFound(new { message = "Contact not found" });

        _context.Contacts.Remove(contact);
        _context.SaveChanges();

        return Ok(new { message = "Contact deleted successfully" });
    }
}