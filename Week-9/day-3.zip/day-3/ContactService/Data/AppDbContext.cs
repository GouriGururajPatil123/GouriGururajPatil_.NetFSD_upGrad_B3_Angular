﻿using Microsoft.EntityFrameworkCore;
using ContactService.Models;

namespace ContactService.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions options) : base(options) { }

    public DbSet<Contact> Contacts { get; set; }

    public DbSet<UserInfo> Users { get; set; }
}