﻿using Microsoft.AspNetCore.Mvc;
using CategoryService.Data;
using CategoryService.Models;

namespace CategoryService.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CategoryController : ControllerBase
{
    private readonly AppDbContext _context;

    public CategoryController(AppDbContext context)
    {
        _context = context;
    }

    // GET ALL
    [HttpGet]
    public IActionResult GetAll()
    {
        var categories = _context.Categories.ToList();
        return Ok(categories);
    }

    // GET BY ID
    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var category = _context.Categories.Find(id);

        if (category == null)
            return NotFound(new { message = "Category not found" });

        return Ok(category);
    }

    // CREATE
    [HttpPost]
    public IActionResult Create(Category category)
    {
        //  Model validation
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // Duplicate check
        var exists = _context.Categories
            .Any(x => x.CategoryName.ToLower() == category.CategoryName.ToLower());

        if (exists)
            return BadRequest(new { message = "Category already exists" });

        _context.Categories.Add(category);
        _context.SaveChanges();

        return Ok(new
        {
            message = "Category created successfully",
            data = category
        });
    }

    // UPDATE
    [HttpPut("{id}")]
    public IActionResult Update(int id, Category updatedCategory)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var category = _context.Categories.Find(id);

        if (category == null)
            return NotFound(new { message = "Category not found" });

        category.CategoryName = updatedCategory.CategoryName;
        category.Description = updatedCategory.Description;

        _context.SaveChanges();

        return Ok(new
        {
            message = "Category updated successfully",
            data = category
        });
    }

    // DELETE
    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var category = _context.Categories.Find(id);

        if (category == null)
            return NotFound(new { message = "Category not found" });

        _context.Categories.Remove(category);
        _context.SaveChanges();

        return Ok(new { message = "Category deleted successfully" });
    }
}