﻿using System.ComponentModel.DataAnnotations;

namespace CategoryService.Models;

public class Category
{
    public int CategoryId { get; set; }

    [Required(ErrorMessage = "Category name is required")]
    [MinLength(3, ErrorMessage = "Category name must be at least 3 characters")]
    [MaxLength(50, ErrorMessage = "Category name cannot exceed 50 characters")]
    public string CategoryName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Description is required")]
    [MinLength(5, ErrorMessage = "Description must be at least 5 characters")]
    [MaxLength(200, ErrorMessage = "Description cannot exceed 200 characters")]
    public string Description { get; set; } = string.Empty;
}