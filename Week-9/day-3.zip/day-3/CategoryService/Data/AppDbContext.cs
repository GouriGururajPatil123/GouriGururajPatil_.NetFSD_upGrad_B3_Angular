﻿using Microsoft.EntityFrameworkCore;
using CategoryService.Models;

namespace CategoryService.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions options) : base(options) { }

    public DbSet<Category> Categories { get; set; } 
}