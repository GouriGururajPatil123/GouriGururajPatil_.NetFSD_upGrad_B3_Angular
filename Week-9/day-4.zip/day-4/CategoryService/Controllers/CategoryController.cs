﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using CategoryService.Models;

namespace CategoryService.Controllers;

[ApiController]
[Route("api/categories")]
[Authorize]
public class CategoryController : ControllerBase
{
    static List<Category> categories = new();

    [HttpGet]
    public IActionResult GetAll() => Ok(categories);

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public IActionResult Add(Category c)
    {
        categories.Add(c);
        return Ok(c);
    }
}