﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ContactService.Models;

namespace ContactService.Controllers;

[ApiController]
[Route("api/contacts")]
[Authorize]
public class ContactController : ControllerBase
{
    static List<Contact> contacts = new();

    [HttpGet]
    public IActionResult GetAll() => Ok(contacts);

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public IActionResult Add(Contact c)
    {
        contacts.Add(c);
        return Ok(c);
    }
}