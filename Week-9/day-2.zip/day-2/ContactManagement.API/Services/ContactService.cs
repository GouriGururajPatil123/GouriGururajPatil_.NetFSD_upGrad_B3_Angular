﻿using ContactManagement.API.Models;
using ContactManagement.API.Repositories;
using Microsoft.Extensions.Caching.Memory;

namespace ContactManagement.API.Services;

public class ContactService
{
    private readonly IContactRepository _repo;
    private readonly IMemoryCache _cache;

    public ContactService(IContactRepository repo, IMemoryCache cache)
    {
        _repo = repo;
        _cache = cache;
    }

    // GET ALL (CACHE 60 sec)
    public List<Contact> GetAll()
    {
        string key = "contact_list";

        if (!_cache.TryGetValue(key, out List<Contact>? contacts))
        {
            contacts = _repo.GetAll();

            _cache.Set(key, contacts, TimeSpan.FromSeconds(60));
        }

        return contacts!;
    }

    // GET BY ID (CACHE 60 sec)
    public Contact? GetById(int id)
    {
        string key = $"contact_{id}";

        if (!_cache.TryGetValue(key, out Contact? contact))
        {
            contact = _repo.GetById(id);

            if (contact != null)
            {
                _cache.Set(key, contact, TimeSpan.FromSeconds(60));
            }
        }

        return contact;
    }
}