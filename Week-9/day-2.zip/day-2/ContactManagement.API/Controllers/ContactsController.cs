﻿using ContactManagement.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace ContactManagement.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ContactsController : ControllerBase
{
    private readonly ContactService _service;

    public ContactsController(ContactService service)
    {
        _service = service;
    }

    // ================= GET ALL + PAGING =================
    [HttpGet]
    public IActionResult GetAll(int pageNumber = 1, int pageSize = 5)
    {
        var data = _service.GetAll();

        var totalRecords = data.Count;
        var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

        var pagedData = data
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToList();

        return Ok(new
        {
            totalRecords,
            totalPages,
            currentPage = pageNumber,
            pageSize,
            data = pagedData
        });
    }

    // ================= GET BY ID =================
    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var contact = _service.GetById(id);

        if (contact == null)
            return NotFound();

        return Ok(contact);
    }
}