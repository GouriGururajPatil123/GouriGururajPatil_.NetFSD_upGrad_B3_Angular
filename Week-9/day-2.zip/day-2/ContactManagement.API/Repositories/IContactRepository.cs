﻿using ContactManagement.API.Models;

namespace ContactManagement.API.Repositories;

public interface IContactRepository
{
    List<Contact> GetAll();
    Contact? GetById(int id);
}