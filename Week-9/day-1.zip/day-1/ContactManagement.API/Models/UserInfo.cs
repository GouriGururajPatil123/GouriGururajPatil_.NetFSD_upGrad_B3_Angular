﻿namespace ContactManagement.API.Models;

public class UserInfo
{
    public int Id { get; set; }  

    public string EmailId { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
}