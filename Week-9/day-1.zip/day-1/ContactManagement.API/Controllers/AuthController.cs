﻿using Microsoft.AspNetCore.Mvc;
using ContactManagement.API.Data;
using ContactManagement.API.Models;
using ContactManagement.API.Services;

namespace ContactManagement.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly JwtService _jwt;

    public AuthController(AppDbContext context, JwtService jwt)
    {
        _context = context;
        _jwt = jwt;
    }

    [HttpPost("register")]
    public IActionResult Register(UserInfo user)
    {
        _context.Users.Add(user);
        _context.SaveChanges();
        return Ok("User registered successfully");
    }

    [HttpPost("login")]
    public IActionResult Login(LoginRequest request)
    {
        var user = _context.Users.FirstOrDefault(x =>
            x.EmailId == request.Email && x.Password == request.Password);

        if (user == null)
            return Unauthorized("Invalid credentials");

        var token = _jwt.GenerateToken(user);
        return Ok(new { token });
    }
}