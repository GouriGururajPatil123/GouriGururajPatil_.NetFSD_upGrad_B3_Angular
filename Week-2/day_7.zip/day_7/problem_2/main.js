import { calculateTotal } from './cart.js';
const result = calculateTotal();

console.log(result);