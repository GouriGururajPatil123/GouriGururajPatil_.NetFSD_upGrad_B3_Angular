//  Storing products in array of objects
const products =[
     { name: "Laptop", price: 50000, quantity: 1 },
    { name: "Mouse", price: 500, quantity: 2 },
    { name: "Keyboard", price: 1500, quantity: 1 }
];
// Arrow function to calculate total

const calculateTotal =() =>{
  // Using map() to calculate total price of each product
const itemTotals = products.map(p => p.price * p.quantity);

 // Using reduce() to calculate grand total
    const grandTotal = itemTotals.reduce((total, value) => total + value, 0);

    // Creating invoice using template literals

    const invoice=`

    -------- CART SUMMARY --------

    ${products.map(p => `${p.name} - ${p.price} x  ${p.quantity} = ${p.price * p.quantity} `) .join("\n")}
   Total Amount = ${grandTotal} `;
    return invoice;
};
// Exporting function
export { calculateTotal };
// This makes function available to other files.