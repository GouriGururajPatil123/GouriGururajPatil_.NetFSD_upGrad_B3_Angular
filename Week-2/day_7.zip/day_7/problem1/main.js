import { analyzeMarks } from './student.js';
const result = analyzeMarks();
console.log(result);

