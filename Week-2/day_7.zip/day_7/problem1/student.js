const marks = [78, 85, 62, 90, 55];
const analyzeMarks = () => {
//  Using reduce() to calculate total
// reduce() adds all numbers in array.
    const total = marks.reduce((sum, value) => sum + value, 0);
  // Calculating average
    const average = total / marks.length;
// Decide pass or fail
  const result = average >= 40 ? "Pass" : "Fail";

// Using template literals to format output
    const output = `
    
------ STUDENT MARKS ANALYSIS ------

Marks: ${marks.map(m => m).join(", ")}

Total Marks: ${total}
Average Marks: ${average.toFixed(2)}

Final Result: ${result}
`;

    return output;
};

// Export function
export { analyzeMarks };