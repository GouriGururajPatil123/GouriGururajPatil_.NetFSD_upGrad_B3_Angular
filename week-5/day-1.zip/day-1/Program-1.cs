﻿/* Level-1 Problem 1: Bank Account Management System
Scenario:
A bank wants to develop a simple console-based application to manage customer bank accounts. The system should protect account balance information and allow controlled access using properties.
Requirements:
1. Create a BankAccount class with private fields for account number and balance.
2. Use properties to allow controlled access to account number and balance.
3. Implement Deposit and Withdraw methods with proper validation.
4. Prevent withdrawal if balance is insufficient.
Technical Constraints:
• Use private fields with public properties.
• Apply encapsulation and data hiding.
• No direct access to balance field from outside the class.
 */

using System;

namespace BankApp
{
    class BankAccount
    {
        private string _accountNumber;
        private decimal _balance;

        // Public property for AccountNumber
        public string AccountNumber
        {
            get { return _accountNumber; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                    _accountNumber = value;
                else
                    Console.WriteLine("Invalid account number.");
            }
        }
        // Public property for Balance (read-only outside)
        public decimal Balance
        {
            get { return _balance; }
            private set { _balance = value; }
        }
        // Constructor
        public BankAccount(string accountNumber, decimal initialBalance = 0)
        {
            AccountNumber = accountNumber;
            if (initialBalance >= 0)
                _balance = initialBalance;
            else
                Console.WriteLine("Initial balance cannot be negative.");
        }
        // Deposit method
        public void Deposit(decimal amount)
        {
            if (amount > 0)
            {
                _balance += amount;
                Console.WriteLine($"Deposited: {amount}. Current Balance: {_balance}");
            }
            else
            {
                Console.WriteLine("Deposit amount must be positive.");
            }
        }
        // Withdraw method
        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                Console.WriteLine("Withdrawal amount must be positive.");
            }
            else if (amount > _balance)
            {
                Console.WriteLine("Insufficient balance. Withdrawal denied.");
            }
            else
            {
                _balance -= amount;
                Console.WriteLine($"Withdrawn: {amount}. Current Balance: {_balance}");
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount("ACC12345");
            account.Deposit(5000);
            account.Withdraw(2000);

            // Display final balance
            Console.WriteLine($"Final Balance = {account.Balance}");
        }
    }
}