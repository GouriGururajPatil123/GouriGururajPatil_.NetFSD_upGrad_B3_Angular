﻿/* Level-2 Problem 2: Vehicle Rental System
Scenario:
A vehicle rental company wants a system where different vehicle types calculate rental charges differently.
Requirements:
1. Create a base class Vehicle with properties Brand and RentalRatePerDay.
2. Create derived classes Car and Bike.
3. Override CalculateRental(int days) method.
4. Car adds insurance charge of 500 per rental.
5. Bike offers 5% discount on total rental.
Technical Constraints:
• Use encapsulation with proper access modifiers.
• Apply runtime polymorphism.
• Validate number of rental days.
 */

using System;

namespace VehicleRentalApp
{
    class Vehicle
    {
        private decimal _rentalRatePerDay;

        // Properties
        public string Brand { get; set; }
        public decimal RentalRatePerDay
        {
            get { return _rentalRatePerDay; }
            set
            {
                if (value >= 0)
                    _rentalRatePerDay = value;
                else
                    Console.WriteLine("Rental rate cannot be negative. Keeping previous value.");
            }
        }

        // Constructor
        public Vehicle(string brand, decimal rate)
        {
            Brand = brand;
            RentalRatePerDay = rate;
        }

        // Virtual method to calculate rental
        public virtual decimal CalculateRental(int days)
        {
            if (days <= 0)
            {
                Console.WriteLine("Rental days must be positive.");
                return 0;
            }
            return RentalRatePerDay * days;
        }
    }

    // Derived class Car
    class Car : Vehicle    {
       public Car(string brand, decimal rate) : base(brand, rate) { }
        public override decimal CalculateRental(int days)
        {
            if (days <= 0)
            {
                Console.WriteLine("Rental days must be positive.");
                return 0;
            }

            decimal baseRental = base.CalculateRental(days);
            decimal insurance = 500m; // fixed insurance per rental
            return baseRental + insurance;
        }
    }

    // Derived class Bike
    class Bike : Vehicle
    {
        public Bike(string brand, decimal rate) : base(brand, rate) { }

        public override decimal CalculateRental(int days)
        {
            if (days <= 0)
            {
                Console.WriteLine("Rental days must be positive.");
                return 0;
            }

            decimal baseRental = base.CalculateRental(days);
            decimal discount = baseRental * 0.05m; // 5% discount
            return baseRental - discount;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Sample rental
            Vehicle car = new Car("Toyota", 2000m);
            Vehicle bike = new Bike("Yamaha", 800m);

            int carDays = 3;
            int bikeDays = 4;

            // Calculate and display rentals
            Console.WriteLine($"{car.Brand} Total Rental for {carDays} days = {car.CalculateRental(carDays)}");
            Console.WriteLine($"{bike.Brand} Total Rental for {bikeDays} days = {bike.CalculateRental(bikeDays)}");
        }
    }
}