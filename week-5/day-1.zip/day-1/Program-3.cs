﻿/* Level-2 Problem 1: Online Shopping Cart System
Scenario:
An e-commerce platform needs a flexible cart system where different product types calculate discounts differently.
Requirements:
1. Create a base class Product with properties Name and Price.
2. Create derived classes Electronics and Clothing.
3. Implement a virtual method CalculateDiscount().
4. Electronics get 5% discount, Clothing gets 15% discount.
5. Use encapsulation to protect price updates.
Technical Constraints:
• Use private fields with public properties.
• Apply inheritance and method overriding.
• Prevent negative price assignment.
 */

using System;

namespace ShoppingCartApp
{
    class Product
    {
        private decimal _price;

        // Properties
        public string Name { get; set; }

        public decimal Price
        {
            get { return _price; }
            set
            {
                if (value >= 0)
                    _price = value;
                else
                    Console.WriteLine("Price cannot be negative. Keeping previous value.");
            }
        }

        // Constructor
        public Product(string name, decimal price)
        {
            Name = name;
            Price = price;
        }

        // Virtual method for discount
        public virtual decimal CalculateDiscount()
        {
            return Price; 
        }
    }

    // Derived class Electronics
    class Electronics : Product
    {
        public Electronics(string name, decimal price) : base(name, price) { }

        public override decimal CalculateDiscount()
        {
            return Price - (Price * 0.05m); // 5% discount
        }
    }

    // Derived class Clothing
    class Clothing : Product
    {
        public Clothing(string name, decimal price) : base(name, price) { }

        public override decimal CalculateDiscount()
        {
            return Price - (Price * 0.15m); // 15% discount
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Product laptop = new Electronics("Laptop", 20000m);
            Product shirt = new Clothing("Shirt", 1000m);

            // Polymorphic discount calculation
            Console.WriteLine($"{laptop.Name} Final Price after discount = {laptop.CalculateDiscount()}");
            Console.WriteLine($"{shirt.Name} Final Price after discount = {shirt.CalculateDiscount()}");
        }
    }
}