﻿/* Level-1 Problem 2: Employee Salary Calculator
Scenario:
A company wants to calculate employee salaries using inheritance. All employees have a base salary, but different roles calculate bonuses differently.
Requirements:
1. Create a base class Employee with Name and BaseSalary properties.
2. Create derived classes Manager and Developer.
3. Override a virtual method CalculateSalary().
4. Manager gets 20% bonus, Developer gets 10% bonus.
Technical Constraints:
• Use inheritance and method overriding.
• Apply polymorphism using base class reference.
• Use properties for salary details.
*/

using System;

namespace EmployeeSalaryApp
{
    class Employee
    {
        public string Name { get; set; }
        public decimal BaseSalary { get; set; }

        // Constructor
        public Employee(string name, decimal baseSalary)
        {
            Name = name;
            BaseSalary = baseSalary;
        }
        // Virtual method to calculate salary
        public virtual decimal CalculateSalary()
        {
            return BaseSalary; 
        }
    }

    // Derived class for Manager
    class Manager : Employee
    {
        public Manager(string name, decimal baseSalary) : base(name, baseSalary) { }

        // Override method to include 20% bonus
        public override decimal CalculateSalary()
        {
            return BaseSalary + (BaseSalary * 0.20m);
        }
    }
    // Derived class for Developer
    class Developer : Employee
    {
        public Developer(string name, decimal baseSalary) : base(name, baseSalary) { }

        // Override method to include 10% bonus
        public override decimal CalculateSalary()
        {
            return BaseSalary + (BaseSalary * 0.10m);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            decimal baseSalary = 50000m;
            Employee manager = new Manager("Alice", baseSalary);
            Employee developer = new Developer("Bob", baseSalary);

            // Display salaries
            Console.WriteLine($"Manager Salary = {manager.CalculateSalary()}");
            Console.WriteLine($"Developer Salary = {developer.CalculateSalary()}");
        }
    }
}