﻿using System;
using System.Collections.Generic;

namespace ToDoApp
{
    class Program
    {
        static void Main()
        {
            List<string> tasks = new List<string>();
            int choice;

            do
            {
                Console.WriteLine("\n To-Do List Manager");
                Console.WriteLine("1. Add Task");
                Console.WriteLine("2. View Tasks");
                Console.WriteLine("3. Remove Task");
                Console.WriteLine("4. Exit");
                Console.Write("Choose an option: ");

                // Validate menu input
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid input! Please enter a number.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        // Add Task
                        Console.Write("Enter task: ");
                        string task = Console.ReadLine();

                        if (!string.IsNullOrWhiteSpace(task))
                        {
                            tasks.Add(task);
                            Console.WriteLine("Task added..");
                        }
                        else
                        {
                            Console.WriteLine("Task cannot be empty.");
                        }
                        break;

                    case 2:
                        // View Tasks
                        if (tasks.Count == 0)
                        {
                            Console.WriteLine("No tasks available.");
                        }
                        else
                        {
                            Console.WriteLine("Tasks:");
                            for (int i = 0; i < tasks.Count; i++)
                            {
                                Console.WriteLine($"{i + 1}. {tasks[i]}");
                            }
                        }
                        break;

                    case 3:
                        // Remove Task
                        if (tasks.Count == 0)
                        {
                            Console.WriteLine("No tasks to remove.");
                            break;
                        }

                        Console.Write("Enter task number to remove: ");

                        if (int.TryParse(Console.ReadLine(), out int taskNo))
                        {
                            if (taskNo >= 1 && taskNo <= tasks.Count)
                            {
                                string removedTask = tasks[taskNo - 1];
                                tasks.RemoveAt(taskNo - 1);
                                Console.WriteLine($"Removed: {removedTask}");
                            }
                            else
                            {
                                Console.WriteLine("Invalid task number.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid input! Please enter a number.");
                        }
                        break;

                    case 4:
                        Console.WriteLine("Exiting application...");
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }

            } while (choice != 4);
        }
    }
}
