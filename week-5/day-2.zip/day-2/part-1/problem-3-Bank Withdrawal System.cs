﻿/* Level-2 Problem 1: Bank Withdrawal System with Custom Exception
Scenario:
A bank wants to implement a withdrawal system that throws a custom exception when a customer attempts to withdraw more money than available in their account.
Requirements:
1.	Create a class BankAccount with a private field balance.
2.	Create a method Withdraw(double amount).
3.	Create a custom exception class InsufficientBalanceException.
4.	Throw the custom exception if the withdrawal amount exceeds the balance.
5.	Handle the exception in the main program using try-catch.
6.	Ensure proper cleanup using a finally block.
Technical Constraints:
•	Use custom exception classes by inheriting from Exception.
•	Implement error propagation by throwing exceptions from methods.
•	Handle exceptions in the calling method.
Expectations:
•	Demonstrate creation and usage of custom exceptions.
•	Implement proper exception handling in calling code.
•	Display user-friendly error messages.
Learning Outcome:
•	Learn how to create custom exceptions.
•	Understand throw and error propagation.
•	Apply structured exception handling in real-world scenarios.
Sample Input:
Balance = 3000
Withdraw = 5000
Sample Output:
Error: Withdrawal amount exceeds available balance*/

using System;
namespace BankWithdrawalSystem
{
    // Custom Exception Class
    public class InsufficientBalanceException : Exception
    {
        public InsufficientBalanceException(string message) : base(message)
        {
        }
    }

    // BankAccount class
    public class BankAccount
    {
        private double balance;

        public BankAccount(double initialBalance)
        {
            balance = initialBalance;
        }

        //  Withdraw method
        public void Withdraw(double amount)
        {
            if (amount > balance)
            {
                // Throw custom exception
                throw new InsufficientBalanceException("Error: Withdrawal amount exceeds available balance");
            }

            balance -= amount;
            Console.WriteLine($"Withdrawal successful. Remaining balance: {balance}");
        }

        //method to display balance
        public void DisplayBalance()
        {
            Console.WriteLine($"Current balance: {balance}");
        }
    }

    class Program
    {
        static void Main()
        {
            Console.Write("Enter initial account balance: ");
            double initialBalance;
            while (!double.TryParse(Console.ReadLine(), out initialBalance) || initialBalance < 0)
            {
                Console.Write("Invalid input! Enter a positive number: ");
            }

            BankAccount account = new BankAccount(initialBalance);

            Console.Write("Enter amount to withdraw: ");
            double withdrawAmount;
            while (!double.TryParse(Console.ReadLine(), out withdrawAmount) || withdrawAmount < 0)
            {
                Console.Write("Invalid input! Enter a positive number: ");
            }

            // Handle exception in main program
            try
            {
                account.Withdraw(withdrawAmount);
            }
            catch (InsufficientBalanceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Transaction completed.");
                account.DisplayBalance();
            }
            Console.ReadLine();
        }
    }
}
