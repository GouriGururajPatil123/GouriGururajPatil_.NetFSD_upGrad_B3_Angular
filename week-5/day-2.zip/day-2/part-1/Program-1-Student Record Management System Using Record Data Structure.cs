﻿/* Level-1 Problem 1: Student Record Management System Using Record Data Structure

Scenario:
A college wants to develop a console-based Student Record Management System. The system should store and manage student records using a Record data structure. Each student record should contain fields such as Roll Number, Name, Course, and Marks. The system must allow users to add multiple student records, display all records, and search for a student using the Roll Number.
Requirements:
1. Define a Record to store student details.
2. Allow the user to input details for multiple students.
3. Display all student records in a formatted manner.
4. Provide a search functionality to find a student by Roll Number.
5. Display appropriate message if the record is not found.
Technical Constraints:
1. Must use Record data type.
2. Use an array (or list) of records to store multiple students.
3. Do not use external databases.
4. Program should be menu-driven.
5. Input validation must be handled for Roll Number and Marks.

Sample Input:
Enter number of students: 2
Enter Roll Number: 101
Enter Name: Aisha
Enter Course: BCA
Enter Marks: 85

Enter Roll Number: 102
Enter Name: Rahul
Enter Course: BSc
Enter Marks: 78

Search Roll Number: 101

Sample Output:
Student Records:
Roll No: 101 | Name: Aisha | Course: BCA | Marks: 85
Roll No: 102 | Name: Rahul | Course: BSc | Marks: 78

Search Result:
Student Found:
Roll No: 101 | Name: Aisha | Course: BCA | Marks: 85*/

using System;

namespace StudentRecordManagement
{
    public record Student(int RollNumber, string Name, string Course, int Marks);

    class Program
    {
        static void Main()
        {
            Console.Write("Enter the number of students: ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Invalid input! Enter a positive number: ");
            }
            //  Array to store student records
            Student[] students = new Student[n];

            //  Input student details
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\nEnter details for student {i + 1}:");
                int roll;
                while (true)
                {
                    Console.Write("Enter Roll Number: ");
                    if (int.TryParse(Console.ReadLine(), out roll) && roll > 0)
                        break;
                    Console.WriteLine("Invalid Roll Number! Must be a positive integer.");
                }

                Console.Write("Enter Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter Course: ");
                string course = Console.ReadLine();

                int marks;
                while (true)
                {
                    Console.Write("Enter Marks (0-100): ");
                    if (int.TryParse(Console.ReadLine(), out marks) && marks >= 0 && marks <= 100)
                        break;
                    Console.WriteLine("Invalid Marks! Enter a number between 0 and 100.");
                }

                // Add student to array
                students[i] = new Student(roll, name, course, marks);
            }

            //  Display all student records
            Console.WriteLine("\n=== Student Records ===");
            foreach (var s in students)
            {
                Console.WriteLine($"Roll No: {s.RollNumber} | Name: {s.Name} | Course: {s.Course} | Marks: {s.Marks}");
            }

            //  Search functionality
            Console.Write("\nEnter Roll Number to search: ");
            int searchRoll;
            while (!int.TryParse(Console.ReadLine(), out searchRoll) || searchRoll <= 0)
            {
                Console.Write("Invalid input! Enter a positive Roll Number: ");
            }

            Student found = null;
            foreach (var s in students)
            {
                if (s.RollNumber == searchRoll)
                {
                    found = s;
                    break;
                }
            }

            // Display search result
            Console.WriteLine("\n=== Search Result ===");
            if (found != null)
            {
                Console.WriteLine($"Student Found:\nRoll No: {found.RollNumber} | Name: {found.Name} | Course: {found.Course} | Marks: {found.Marks}");
            }
            else
            {
                Console.WriteLine("Student record not found!");
            }

            Console.WriteLine("\nPress Enter to exit...");
            Console.ReadLine();
        }
    }
}