﻿/* Level-2 Problem 2: Employee Management Using Linked List
Scenario:
A company wants to maintain employee records dynamically using a Linked List structure.
Requirements:
- Create Node structure with employee ID and name.
- Implement insertion at beginning and end.
- Implement deletion by employee ID.
- Traverse and display employee list.
Technical Constraints:
- Must implement singly linked list.
- No use of built-in list structures.
- Proper memory handling and pointer updates.
Sample Input:
Insert: (101, John), (102, Sara), (103, Mike)
Delete: 102
Sample Output:
Employee List After Deletion:
101 - John
103 – Mike

Expectations:
- Correct node linking.
- Efficient traversal logic.
- Clean insertion and deletion operations.
Learning Outcome:
- Understand linked list structure.
- Perform insertion and deletion operations.
- Learn dynamic data structure behavior.*/

using System;

namespace EmployeeLinkedList
{
    // Node structure for each employee
    class EmployeeNode
    {
        public int EmployeeID;
        public string Name;
        public EmployeeNode Next;

        public EmployeeNode(int id, string name)
        {
            EmployeeID = id;
            Name = name;
            Next = null;
        }
    }

    //  Singly Linked List Class
    class EmployeeList
    {
        private EmployeeNode head;

        public EmployeeList()
        {
            head = null;
        }

        // Insert at beginning
        public void InsertAtBeginning(int id, string name)
        {
            EmployeeNode newNode = new EmployeeNode(id, name);
            newNode.Next = head;
            head = newNode;
            Console.WriteLine($"Inserted {id} - {name} at the beginning.");
        }

        // Insert at end
        public void InsertAtEnd(int id, string name)
        {
            EmployeeNode newNode = new EmployeeNode(id, name);
            if (head == null)
            {
                head = newNode;
            }
            else
            {
                EmployeeNode temp = head;
                while (temp.Next != null)
                {
                    temp = temp.Next;
                }
                temp.Next = newNode;
            }
            Console.WriteLine($"Inserted {id} - {name} at the end.");
        }

        // Delete by EmployeeID
        public void DeleteByID(int id)
        {
            if (head == null)
            {
                Console.WriteLine("Employee list is empty. Nothing to delete.");
                return;
            }

            if (head.EmployeeID == id)
            {
                Console.WriteLine($"Deleted {head.EmployeeID} - {head.Name}");
                head = head.Next;
                return;
            }

            EmployeeNode current = head;
            EmployeeNode previous = null;

            while (current != null && current.EmployeeID != id)
            {
                previous = current;
                current = current.Next;
            }

            if (current == null)
            {
                Console.WriteLine($"Employee with ID {id} not found.");
            }
            else
            {
                previous.Next = current.Next;
                Console.WriteLine($"Deleted {current.EmployeeID} - {current.Name}");
            }
        }

        // Traverse and display list
        public void DisplayList()
        {
            if (head == null)
            {
                Console.WriteLine("Employee list is empty.");
                return;
            }

            Console.WriteLine("\nEmployee List:");
            EmployeeNode temp = head;
            while (temp != null)
            {
                Console.WriteLine($"{temp.EmployeeID} - {temp.Name}");
                temp = temp.Next;
            }
        }
    }

    class Program
    {
        static void Main()
        {
            EmployeeList employees = new EmployeeList();

            // Sample Insertions
            employees.InsertAtEnd(101, "John");
            employees.InsertAtEnd(102, "Sara");
            employees.InsertAtEnd(103, "Mike");

            // Display after insertion
            employees.DisplayList();

            // Sample Deletion
            Console.WriteLine("\nDeleting Employee ID 102...");
            employees.DeleteByID(102);

            // Display after deletion
            employees.DisplayList();

            Console.WriteLine("\nPress Enter to exit...");
            Console.ReadLine();
        }
    }
}

