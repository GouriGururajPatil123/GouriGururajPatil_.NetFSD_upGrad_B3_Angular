﻿/* Level-1 Problem 1: Stack-Based Undo System
Scenario:
Design a simple text editor undo feature using Stack (LIFO principle).
Requirements:
- Implement stack using arrays.
- Support push (add action) and pop (undo action).
- Display current state after each operation.
Technical Constraints:
- Only array-based stack implementation.
- Must follow LIFO order strictly.
- Handle empty stack condition.
Sample Input:
Actions: Type A, Type B, Type C, Undo, Undo
Sample Output:
Current State After Operations: Type A
Expectations:
- Correct LIFO implementation.
- Proper error handling.
- Clear logic structure.

Learning Outcome:
- Understand stack operations.
- Learn LIFO principle application.
- Implement stack using arrays.
*/

using System;

namespace StackUndoSystem
{
    class Stack
    {
        private string[] actions;
        private int top;
        private int maxSize;

        // Constructor
        public Stack(int size)
        {
            maxSize = size;
            actions = new string[maxSize];
            top = -1; // empty stack
        }

        // Push operation: add action
        public void Push(string action)
        {
            if (top >= maxSize - 1)
            {
                Console.WriteLine("Error: Stack Overflow! Cannot add more actions.");
                return;
            }

            actions[++top] = action;
            Console.WriteLine($"Action '{action}' added.");
            DisplayCurrentState();
        }

        // Pop operation: undo action
        public void Pop()
        {
            if (top < 0)
            {
                Console.WriteLine("Error: Stack is empty! Nothing to undo.");
                return;
            }

            string undoneAction = actions[top--];
            Console.WriteLine($"Action '{undoneAction}' undone.");
            DisplayCurrentState();
        }

        // Display current state
        public void DisplayCurrentState()
        {
            if (top < 0)
            {
                Console.WriteLine("Current State: (empty)\n");
                return;
            }

            Console.Write("Current State: ");
            for (int i = 0; i <= top; i++)
            {
                Console.Write(actions[i]);
                if (i < top)
                    Console.Write(" -> ");
            }
            Console.WriteLine("\n");
        }
    }
    class Program
    {
        static void Main()
        {
            Console.Write("Enter maximum number of actions: ");
            int size;
            while (!int.TryParse(Console.ReadLine(), out size) || size <= 0)
            {
                Console.Write("Invalid input! Enter a positive number: ");
            }

            Stack undoStack = new Stack(size);

            Console.WriteLine("\nCommands: 'Type <text>' to add, 'Undo' to undo, 'Exit' to quit");

            while (true)
            {
                Console.Write("\nEnter command: ");
                string input = Console.ReadLine();

                if (input.Equals("Exit", StringComparison.OrdinalIgnoreCase))
                    break;
                else if (input.StartsWith("Type "))
                {
                    string action = input.Substring(5); // get the text after "Type "
                    undoStack.Push(action);
                }
                else if (input.Equals("Undo", StringComparison.OrdinalIgnoreCase))
                {
                    undoStack.Pop();
                }
                else
                {
                    Console.WriteLine("Invalid command! Use 'Type <text>' or 'Undo' or 'Exit'.");
                }
            }

            Console.WriteLine("\nFinal State:");
            undoStack.DisplayCurrentState();
            Console.WriteLine("Program terminated. Press Enter to exit...");
            Console.ReadLine();
        }
    }
}