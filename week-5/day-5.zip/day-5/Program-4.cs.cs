﻿/* Problem 4 – Level 2
Scenario:
A development team wants to analyze all folders inside a project directory to understand the project structure.
Requirements:
1. Accept a root directory path.
2. Display all subdirectories inside the root folder.
3. Show the number of files present in each directory.
Technical Constraints:
• Use DirectoryInfo class.
• Use loops to iterate through directories.
• Implement exception handling.
Expectations:
The application should display folder names and file counts for each directory.
Learning Outcome:
Students will learn how to navigate directories and retrieve folder information using DirectoryInfo.
 */

using System;
using System.IO;

namespace ConsoleApp41
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // 1. Accept root directory path
                Console.Write("Enter root directory path: ");
                string rootPath = Console.ReadLine();

                // Check if directory exists
                if (!Directory.Exists(rootPath))
                {
                    Console.WriteLine("Invalid directory path!");
                }
                else
                {
                    DirectoryInfo rootDir = new DirectoryInfo(rootPath);

                    // Get all subdirectories
                    DirectoryInfo[] subDirs = rootDir.GetDirectories();

                    if (subDirs.Length == 0)
                    {
                        Console.WriteLine("No subdirectories found in this folder.");
                    }
                    else
                    {
                        Console.WriteLine("\nSubdirectories and File Counts:\n");

                        foreach (DirectoryInfo dir in subDirs)
                        {
                            // Get number of files in the directory
                            int fileCount = dir.GetFiles().Length;

                            Console.WriteLine("Folder Name : " + dir.Name);
                            Console.WriteLine("File Count  : " + fileCount);
                            Console.WriteLine("---------------------------");
                        }
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("Exception: You do not have permission to access this folder.");
            }
            catch (IOException ex)
            {
                Console.WriteLine("File System Error: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Error: " + ex.Message);
            }

            Console.WriteLine("\nPress Enter to exit...");
            Console.ReadLine();
        }
    }
}