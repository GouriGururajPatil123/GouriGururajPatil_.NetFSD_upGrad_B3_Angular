﻿using System;
using System.IO;

namespace ConsoleApp41
{
    class Program
    {
        static void Main(string[] args)
        {
            string dirName = "Logs";

            // Create directory if not exists
            if (!Directory.Exists(dirName))
            {
                Directory.CreateDirectory(dirName);
            }

            string filePath = Path.Combine(dirName, "log_messages.txt");

            try
            {
                Console.Write("Enter your message: ");
                string message = Console.ReadLine();

                using (StreamWriter sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLine(message);
                }

                Console.WriteLine("Message written successfully!");
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("Exception: No permission to access file.");
            }
            catch (IOException ex)
            {
                Console.WriteLine("File Error: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Error: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("Operation completed.");
            }

            // Just wait before closing
            Console.ReadLine();
        }
    }
}



