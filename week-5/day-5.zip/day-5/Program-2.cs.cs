﻿/* Problem 2 – Level 1:
Scenario:
An administrator wants to check file properties stored in a particular folder for auditing purposes.
Requirements:
1. Accept a folder path from the user.
2. Display file name, file size, and creation date.
3. Count and display the total number of files.
Technical Constraints:
• Use FileInfo class.
• Handle invalid directory paths.
Expectations:
The program should list file details clearly in the console.
Learning Outcome:
Students will understand how to retrieve file metadata using FileInfo. */

using System;
using System.IO;

namespace ConsoleApp41
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Ask user for folder path
                Console.Write("Enter folder path: ");
                string folderPath = Console.ReadLine();

                // Check if folder exists
                if (!Directory.Exists(folderPath))
                {
                    Console.WriteLine("Invalid folder path!");
                }
                else
                {
                    // Get all files in the folder
                    string[] files = Directory.GetFiles(folderPath);

                    Console.WriteLine("\nFile Details:\n");

                    foreach (string file in files)
                    {
                        FileInfo fi = new FileInfo(file);

                        Console.WriteLine("File Name     : " + fi.Name);
                        Console.WriteLine("File Size     : " + fi.Length + " bytes");
                        Console.WriteLine("Creation Date : " + fi.CreationTime);
                        Console.WriteLine("---------------------------");
                    }

                    // Display total number of files
                    Console.WriteLine("Total number of files: " + files.Length);
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("Exception: You do not have permission to access this folder.");
            }
            catch (IOException ex)
            {
                Console.WriteLine("File Error: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Error: " + ex.Message);
            }

            Console.ReadLine();
        }
    }
}