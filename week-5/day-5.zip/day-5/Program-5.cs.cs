﻿/*Problem 5 – Level 2
Scenario:
An IT administrator wants to monitor disk storage and identify drives that are running out of space.
Requirements:
1. Retrieve all system drives.
2. Display drive name, drive type, total size, and available free space.
3. Display a warning if free space is below 15%.
Technical Constraints:
• Use DriveInfo class.
• Ensure the drive is ready before accessing properties.
• Use loops to process multiple drives.
Expectations:
The program should display drive health information and warn the user about low disk space.
Learning Outcome:
Students will learn how to retrieve and analyze system storage information using DriveInfo.
*/

using System;
using System.IO;

namespace ConsoleApp41
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Get all drives
                DriveInfo[] drives = DriveInfo.GetDrives();

                Console.WriteLine("--- System Drive Information ---\n");

                foreach (DriveInfo drive in drives)
                {
                    // Check if drive is ready
                    if (drive.IsReady)
                    {
                        string driveName = drive.Name;
                        string driveType = drive.DriveType.ToString();
                        long totalSize = drive.TotalSize;
                        long freeSpace = drive.AvailableFreeSpace;
                        double freePercentage = ((double)freeSpace / totalSize) * 100;

                        Console.WriteLine("Drive Name       : " + driveName);
                        Console.WriteLine("Drive Type       : " + driveType);
                        Console.WriteLine("Total Size       : " + (totalSize / (1024 * 1024 * 1024)) + " GB");
                        Console.WriteLine("Available Space  : " + (freeSpace / (1024 * 1024 * 1024)) + " GB");
                        Console.WriteLine("Free Space (%)   : " + freePercentage.ToString("F2") + "%");

                        // Warning if free space below 15%
                        if (freePercentage < 15)
                        {
                            Console.WriteLine("**Warning: Low Disk Space!**");
                        }

                        Console.WriteLine("-------------------------------");
                    }
                    else
                    {
                        Console.WriteLine("Drive " + drive.Name + " is not ready.");
                        Console.WriteLine("-------------------------------");
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("Exception: Access denied to some drives.");
            }
            catch (IOException ex)
            {
                Console.WriteLine("Drive Error: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected Error: " + ex.Message);
            }

            Console.WriteLine("\nPress Enter to exit...");
            Console.ReadLine();
        }
    }
}