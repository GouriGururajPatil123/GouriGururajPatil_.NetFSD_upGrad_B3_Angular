$(document).ready(function(){

/* =========================
   PRODUCTS PAGE
========================= */

if($("#productList").length){

$.getJSON("data/products.json", function(products){

let html="";

products.forEach(function(product){

html+=`

<div class="col-md-4 mb-4">

<div class="card product-card shadow">

<img src="${product.image}" class="card-img-top product-img">

<div class="card-body text-center">

<h5>${product.name}</h5>

<p class="text-success fw-bold">₹${product.price}</p>

<a href="product-details.html?id=${product.id}" class="btn btn-primary">
View Details
</a>

<button class="btn btn-success addCart" data-id="${product.id}">
Add To Cart
</button>

</div>

</div>

</div>

`;

});

$("#productList").html(html);


/* Add To Cart Button */

$(".addCart").click(function(){

let id=$(this).data("id");

let product = products.find(p => p.id == id);

addToCart(product);

});

});

}


/* =========================
   PRODUCT DETAILS PAGE
========================= */

if($("#productDetails").length){

let params = new URLSearchParams(window.location.search);

let productId = params.get("id");

$.getJSON("data/products.json", function(products){

let product = products.find(p => p.id == productId);

if(product){

let html = `

<div class="row align-items-center">

<div class="col-md-6 text-center">

<img src="${product.image}" class="product-detail-img">

</div>

<div class="col-md-6">

<h2>${product.name}</h2>

<p class="mt-3">${product.description}</p>

<h3 class="text-success">₹${product.price}</h3>

<button class="btn btn-success mt-3" id="addCartBtn">
Add To Cart
</button>

</div>

</div>

`;

$("#productDetails").html(html);


/* Add to cart from details page */

$("#addCartBtn").click(function(){

addToCart(product);

});

}

});

}

});