$(document).ready(function(){

let cart = getCart();

let total = 0;

let html = "";

cart.forEach(function(item){

total += item.price;

html += `
<li class="list-group-item d-flex justify-content-between">
${item.name}
<span>₹${item.price}</span>
</li>
`;

});

$("#orderItems").html(html);

$("#orderTotal").text("₹" + total);


$("#checkoutForm").submit(function(e){

e.preventDefault();

alert("Order placed successfully!");

localStorage.removeItem("cart");

window.location="index.html";

});

});