$(document).ready(function(){

let cart = getCart();

let html = "";

let total = 0;

cart.forEach(function(item,index){

total += item.price;

html += `
<tr>

<td>${item.name}</td>

<td>₹${item.price}</td>

<td>
<button class="btn btn-danger remove" data-index="${index}">
Remove
</button>
</td>

</tr>
`;

});

$("#cartItems").html(html);

$("#total").text("₹" + total);


/* Remove Item */

$(".remove").click(function(){

let index = $(this).data("index");

cart.splice(index,1);

saveCart(cart);

location.reload();

});

});