// student.service.ts

import { Student } from "./student.model.js";
import { PASS_MARKS } from "./constants.js";

// Get grade based on marks
export function getGrade(marks: number): string {
    if (marks >= 80) return "A";
    if (marks >= 60) return "B";
    if (marks >= PASS_MARKS) return "C";
    return "Fail";
}

// Find topper student
export function getTopper(students: Student[]): Student {
    return students.reduce((top, current) =>
        current.marks > top.marks ? current : top
    );
}