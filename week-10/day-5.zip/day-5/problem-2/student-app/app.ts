import { formatName, calculateAverage } from "./utils.js";
import { getGrade, getTopper } from "./student.service.js";
import { Student } from "./student.model.js";

// Sample data
const students: Student[] = [
    { id: 1, name: "gouri", marks: 85 },
    { id: 2, name: "rahul", marks: 70 },
    { id: 3, name: "ankit", marks: 45 },
    { id: 4, name: "meena", marks: 30 }
];

console.log("===== STUDENT DETAILS =====");

students.forEach(student => {
    console.log("ID:", student.id);
    console.log("Name:", formatName(student.name));
    console.log("Marks:", student.marks);
    console.log("Grade:", getGrade(student.marks));
    console.log("----------------------");
});

// Average marks
const avg = calculateAverage(students);
console.log("Average Marks:", avg);

// Topper
const topper = getTopper(students);
console.log("Topper:", formatName(topper.name), "-", topper.marks);