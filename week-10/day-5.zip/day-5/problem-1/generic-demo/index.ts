//  Generic Function

function getFirstElement<T>(items: T[]): T {
    return items[0];
}

//  Generic Interface

interface Repository<T> {
    add(item: T): void;
    getAll(): T[];
}

//  Generic Class Implementation

class DataManager<T> implements Repository<T> {

    private items: T[] = [];

    // Add item
    add(item: T): void {
        this.items.push(item);
    }

    // Get all items
    getAll(): T[] {
        return this.items;
    }
}

//  Models (User & Product)

interface User {
    id: number;
    name: string;
}

interface Product {
    id: number;
    title: string;
}

//  Use Case Implementation


// USER DATA MANAGER
const userManager = new DataManager<User>();

userManager.add({ id: 1, name: "Gouri" });
userManager.add({ id: 2, name: "Anjali" });
userManager.add({ id: 3, name: "Rahul" });

// PRODUCT DATA MANAGER
const productManager = new DataManager<Product>();

productManager.add({ id: 101, title: "Laptop" });
productManager.add({ id: 102, title: "Mobile" });
productManager.add({ id: 103, title: "Keyboard" });

//  Testing Output


console.log("===== USERS =====");
console.log(userManager.getAll());

console.log("First User:");
console.log(getFirstElement<User>(userManager.getAll()));

console.log("===== PRODUCTS =====");
console.log(productManager.getAll());

console.log("First Product:");
console.log(getFirstElement<Product>(productManager.getAll()));