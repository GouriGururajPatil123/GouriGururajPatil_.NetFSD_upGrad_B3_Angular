"use strict";
//  Generic Function
function getFirstElement(items) {
    return items[0];
}
//  Generic Class Implementation
class DataManager {
    items = [];
    // Add item
    add(item) {
        this.items.push(item);
    }
    // Get all items
    getAll() {
        return this.items;
    }
}
//  Use Case Implementation
// USER DATA MANAGER
const userManager = new DataManager();
userManager.add({ id: 1, name: "Gouri" });
userManager.add({ id: 2, name: "Anjali" });
userManager.add({ id: 3, name: "Rahul" });
// PRODUCT DATA MANAGER
const productManager = new DataManager();
productManager.add({ id: 101, title: "Laptop" });
productManager.add({ id: 102, title: "Mobile" });
productManager.add({ id: 103, title: "Keyboard" });
//  Testing Output
console.log("===== USERS =====");
console.log(userManager.getAll());
console.log("First User:");
console.log(getFirstElement(userManager.getAll()));
console.log("===== PRODUCTS =====");
console.log(productManager.getAll());
console.log("First Product:");
console.log(getFirstElement(productManager.getAll()));
