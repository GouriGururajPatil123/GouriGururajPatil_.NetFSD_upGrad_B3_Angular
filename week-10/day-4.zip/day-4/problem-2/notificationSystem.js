"use strict";
// User Notification System (TypeScript)
// 1. Required Parameter Function
function getWelcomeMessage(name) {
    return `Welcome ${name}! Glad to have you in our system.`;
}
// 2. Optional Parameter Function
function getUserInfo(name, age) {
    if (age !== undefined) {
        return `User: ${name}, Age: ${age}`;
    }
    return `User: ${name}`;
}
// 3. Default Parameter Function
function getSubscriptionStatus(name, isSubscribed = false) {
    if (isSubscribed) {
        return `${name} is a Premium Subscriber.`;
    }
    return `${name} is NOT Subscribed.`;
}
// 4. Function with return type boolean
function isEligibleForPremium(age) {
    return age > 18;
}
// 5. Arrow function example
const getAlertMessage = (message) => {
    return `ALERT: ${message}`;
};
// 6. Lexical this Example (IMPORTANT FIX)
const NotificationService = {
    appName: "My Angular App",
    showAppName: function () {
        const arrowFn = () => {
            console.log(`App Name is: ${this.appName}`);
        };
        arrowFn();
    }
};
// 7. Execution (function calls)
console.log("---- Notification System Output ----");
// Required parameter
console.log(getWelcomeMessage("Gouri"));
// Optional parameter
console.log(getUserInfo("Gouri", 22));
console.log(getUserInfo("Rahul"));
// Default parameter
console.log(getSubscriptionStatus("Gouri", true));
console.log(getSubscriptionStatus("Rahul"));
// Boolean return function
console.log("Eligible for Premium:", isEligibleForPremium(20));
console.log("Eligible for Premium:", isEligibleForPremium(16));
// Arrow function
console.log(getAlertMessage("Server Down"));
// Lexical this demo
NotificationService.showAppName();
