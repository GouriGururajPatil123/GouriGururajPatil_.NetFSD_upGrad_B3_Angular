"use strict";
let userName = "John";
let age = 25;
let email = "john@example.com";
let isSubscribed = true;
let country = "India";
let userScore = 85;
const appName = "User Profile Manager";
const minAge = 18;
let updatedAge = age;
updatedAge = updatedAge + 1;
let isEligibleForPremium = (updatedAge > minAge) && isSubscribed;
let userProfileMessage = `
Hello ${userName},
You are ${updatedAge} years old.
Your email is ${email}.
Subscription status: ${isSubscribed ? "Active" : "Inactive"}
`;
console.log(appName);
console.log(userProfileMessage);
console.log(country);
console.log(userScore);
console.log(isEligibleForPremium);
