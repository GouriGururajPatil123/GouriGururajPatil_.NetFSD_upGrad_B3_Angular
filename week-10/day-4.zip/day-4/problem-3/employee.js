"use strict";
// Employee Management System
// 1. Base Class: Employee
class Employee {
    id;
    name;
    salary;
    // Constructor
    constructor(id, name, salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
    // Getter for salary
    getSalary() {
        return this.salary;
    }
    // Setter for salary with validation
    setSalary(value) {
        if (value > 0) {
            this.salary = value;
        }
        else {
            console.log("Invalid salary. Must be greater than 0.");
        }
    }
    // Method to display employee details
    displayDetails() {
        console.log("Employee Details:");
        console.log(`ID: ${this.id}`);
        console.log(`Name: ${this.name}`);
        console.log(`Salary: ${this.salary}`);
    }
}
// 2. Derived Class: Manager
class Manager extends Employee {
    teamSize;
    // Constructor using super
    constructor(id, name, salary, teamSize) {
        super(id, name, salary);
        this.teamSize = teamSize;
    }
    // Override displayDetails method
    displayDetails() {
        console.log("Manager Details:");
        console.log(`ID: ${this.id}`);
        console.log(`Name: ${this.name}`);
        console.log(`Salary: ${this.getSalary()}`);
        console.log(`Team Size: ${this.teamSize}`);
    }
}
// 3. Object Creation & Execution
// Employee object
let emp1 = new Employee(101, "Gouri", 30000);
// Manager object
let mgr1 = new Manager(201, "Rahul", 60000, 10);
// Display Employee
emp1.displayDetails();
console.log("----------------------");
// Display Manager
mgr1.displayDetails();
console.log("----------------------");
// Getter & Setter demo
console.log("Employee Salary:", emp1.getSalary());
emp1.setSalary(35000);
console.log("Updated Salary:", emp1.getSalary());
// Invalid salary test
emp1.setSalary(-500);
