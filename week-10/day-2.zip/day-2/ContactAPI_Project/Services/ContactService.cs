﻿using ContactAPI_Project.Interfaces;
using ContactAPI_Project.Models;

namespace ContactAPI_Project.Services
{
    public class ContactService : IContactService
    {
        private readonly List<Contact> _contacts = new();

        public List<Contact> GetAll()
        {
            return _contacts;
        }

        public Contact? GetById(int id)
        {
            return _contacts.FirstOrDefault(x => x.Id == id);
        }

        public void Add(Contact contact)
        {
            if (contact == null)
                throw new ArgumentNullException(nameof(contact));

            if (_contacts.Any(c => c.Id == contact.Id))
                throw new Exception("Contact already exists");

            _contacts.Add(contact);
        }

        public void Update(int id, Contact contact)
        {
            var existing = _contacts.FirstOrDefault(x => x.Id == id);

            if (existing == null)
                throw new Exception("Contact not found");

            existing.Name = contact.Name;
            existing.Email = contact.Email;
            existing.Phone = contact.Phone;
        }

        public void Delete(int id)
        {
            var contact = _contacts.FirstOrDefault(x => x.Id == id);

            if (contact != null)
            {
                _contacts.Remove(contact);
            }
        }
    }
}