﻿using ContactAPI_Project.Interfaces;
using ContactAPI_Project.Models;
using Microsoft.AspNetCore.Mvc;

namespace ContactAPI_Project.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactsController : ControllerBase
    {
        private readonly IContactService _service;

        public ContactsController(IContactService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAll());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var contact = _service.GetById(id);

            if (contact == null)
                return NotFound();

            return Ok(contact);
        }

        [HttpPost]
        public IActionResult Add(Contact contact)
        {
            _service.Add(contact);
            return Ok("Added successfully");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Contact contact)
        {
            _service.Update(id, contact);
            return Ok("Updated successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _service.Delete(id);
            return Ok("Deleted successfully");
        }
    }
}