﻿using System;
using ContactManagementApp.Models;
using ContactManagementApp.Services;

class Program
{
    static void Main()
    {
        var service = new ContactService();

        service.AddContact(new Contact { Id = 1, Name = "John", Email = "john@gmail.com", Phone = "9876543210" });
        service.AddContact(new Contact { Id = 2, Name = "Mary", Email = "mary@gmail.com", Phone = "9123456780" });
        service.AddContact(new Contact { Id = 3, Name = "Alex", Email = "alex@gmail.com", Phone = "9000000000" });

        service.UpdateContact(new Contact { Id = 1, Name = "John Updated", Email = "johnnew@gmail.com", Phone = "9999999999" });

        // DELETE REMOVED so all output is shown

        service.DeleteContact(2);

        Console.WriteLine("\n===== CONTACT LIST =====\n");

        foreach (var c in service.GetAllContacts())
        {
            Console.WriteLine($"ID: {c.Id}");
            Console.WriteLine($"Name: {c.Name}");
            Console.WriteLine($"Email: {c.Email}");
            Console.WriteLine($"Phone: {c.Phone}");
            Console.WriteLine("----------------------");
        }

        Console.ReadLine();

    }
}