﻿using ContactManagementApp.Models;
using System.Collections.Generic;

namespace ContactManagementApp.Interfaces
{
    public interface IContactService
    {
        void AddContact(Contact contact);
        void UpdateContact(Contact contact);
        void DeleteContact(int id);
        List<Contact> GetAllContacts();
    }
}