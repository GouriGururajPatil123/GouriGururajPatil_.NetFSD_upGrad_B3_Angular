﻿using ContactManagementApp.Interfaces;
using ContactManagementApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ContactManagementApp.Services
{
    public class ContactService : IContactService
    {
        private readonly List<Contact> _contacts = new();

        public void AddContact(Contact contact)
        {
            if (contact == null)
                throw new ArgumentNullException(nameof(contact));

            if (string.IsNullOrWhiteSpace(contact.Name))
                throw new ArgumentException("Name is required");

            if (_contacts.Any(c => c.Id == contact.Id))
                throw new Exception("Contact already exists");

            _contacts.Add(contact);

            Console.WriteLine($"[ADDED] Contact ID {contact.Id}");
        }

        public void UpdateContact(Contact contact)
        {
            if (contact == null)
                throw new ArgumentNullException(nameof(contact));

            var existing = _contacts.FirstOrDefault(c => c.Id == contact.Id);

            if (existing == null)
            {
                Console.WriteLine($"[UPDATE FAILED] Contact ID {contact.Id} not found");
                return;
            }

            existing.Name = contact.Name;
            existing.Email = contact.Email;
            existing.Phone = contact.Phone;

            Console.WriteLine($"[UPDATED] Contact ID {contact.Id}");
        }

        public void DeleteContact(int id)
        {
            var contact = _contacts.FirstOrDefault(c => c.Id == id);

            if (contact != null)
            {
                _contacts.Remove(contact);
                Console.WriteLine($"[DELETED] Contact ID {id}");
            }
            else
            {
                Console.WriteLine($"[DELETE FAILED] Contact ID {id} not found");
            }
        }

        public List<Contact> GetAllContacts()
        {
            return _contacts;
        }
    }
}