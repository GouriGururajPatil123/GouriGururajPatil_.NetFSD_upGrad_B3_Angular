﻿using Microsoft.AspNetCore.Mvc;
using WebApplication7.Models;
using WebApplication7.Services;

namespace WebApplication7.Controllers
{
    public class ContactController : Controller
    {
        private readonly IContactService _contactService;

        public ContactController(IContactService contactService)
        {
            _contactService = contactService;
        }

        // ✅ SHOW + SEARCH
        public IActionResult ShowContacts(int? id)
        {
            var contacts = _contactService.GetAllContacts();

            if (id.HasValue)
            {
                var contact = _contactService.GetContactById(id.Value);

                if (contact != null)
                {
                    contacts = new List<ContactInfo> { contact };
                }
                else
                {
                    ViewBag.Message = "Contact not found";
                    contacts = new List<ContactInfo>();
                }
            }

            return View(contacts);
        }

        // ✅ GET METHOD
        public IActionResult AddContact()
        {
            return View();
        }

        // ✅ POST METHOD WITH VALIDATION ⭐
        [HttpPost]
        public IActionResult AddContact(ContactInfo contactInfo)
        {
            if (ModelState.IsValid)   // ✅ validation check
            {
                _contactService.AddContact(contactInfo);
                return RedirectToAction("ShowContacts");
            }

            // ❌ if validation fails → stay on same page
            return View(contactInfo);
        }
    }
}