﻿using Microsoft.EntityFrameworkCore;
using WebApplication7.Models;

namespace WebApplication7.Data
{
    public class ApplicationDbContextSR : DbContext
    {
        public ApplicationDbContextSR(DbContextOptions<ApplicationDbContextSR> options)
            : base(options)
        {
        }

        public DbSet<MovieSR> MoviesSR { get; set; }
    }
}