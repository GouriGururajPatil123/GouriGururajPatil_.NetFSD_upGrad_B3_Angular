﻿using WebApplication7.Models;

namespace WebApplication7.Services
{
    public interface IMovieSRService
    {
        List<MovieSR> GetAllMovies();
        MovieSR? GetMovie(int id);
        void AddMovie(MovieSR movie);
        void UpdateMovie(MovieSR movie);
        void DeleteMovie(int id);
    }
}