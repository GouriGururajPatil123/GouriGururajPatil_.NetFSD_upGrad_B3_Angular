﻿using WebApplication7.Models;
using WebApplication7.Repository;

namespace WebApplication7.Services
{
    public class MovieSRService : IMovieSRService
    {
        private readonly IMovieSRRepository _repo;

        public MovieSRService(IMovieSRRepository repo)
        {
            _repo = repo;
        }

        public List<MovieSR> GetAllMovies()
        {
            return _repo.GetAll();
        }

        public MovieSR? GetMovie(int id)
        {
            return _repo.GetById(id);
        }

        public void AddMovie(MovieSR movie)
        {
            _repo.Add(movie);
        }

        public void UpdateMovie(MovieSR movie)
        {
            _repo.Update(movie);
        }

        public void DeleteMovie(int id)
        {
            _repo.Delete(id);
        }
    }
}