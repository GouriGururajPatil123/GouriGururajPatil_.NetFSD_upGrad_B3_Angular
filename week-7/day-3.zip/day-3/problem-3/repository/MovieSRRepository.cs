﻿using WebApplication7.Models;
using WebApplication7.Data;

namespace WebApplication7.Repository
{
    public class MovieSRRepository : IMovieSRRepository
    {
        private readonly ApplicationDbContextSR _context;

        public MovieSRRepository(ApplicationDbContextSR context)
        {
            _context = context;
        }

        public List<MovieSR> GetAll()
        {
            return _context.MoviesSR.ToList();
        }

        public MovieSR? GetById(int id)
        {
            return _context.MoviesSR.Find(id);
        }

        public void Add(MovieSR movie)
        {
            _context.MoviesSR.Add(movie);
            _context.SaveChanges();
        }

        public void Update(MovieSR movie)
        {
            _context.MoviesSR.Update(movie);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var movie = _context.MoviesSR.Find(id);
            if (movie != null)
            {
                _context.MoviesSR.Remove(movie);
                _context.SaveChanges();
            }
        }
    }
}