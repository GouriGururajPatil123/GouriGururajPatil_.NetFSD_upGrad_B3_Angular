﻿using WebApplication7.Models;

namespace WebApplication7.Repository
{
    public interface IMovieSRRepository
    {
        List<MovieSR> GetAll();
        MovieSR? GetById(int id);
        void Add(MovieSR movie);
        void Update(MovieSR movie);
        void Delete(int id);
    }
}