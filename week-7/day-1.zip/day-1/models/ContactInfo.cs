﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication3.Models
{
    public class ContactInfo
    {
        public int ContactId { get; set; }

        [Required(ErrorMessage = "First Name is required")]
        public string FirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Last Name is required")]
        public string LastName { get; set; } = string.Empty;

        public string CompanyName { get; set; } = string.Empty;

        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string EmailId { get; set; } = string.Empty;

        [Phone(ErrorMessage = "Invalid Phone Number")]
        public string MobileNo { get; set; } = string.Empty; 

        public string Designation { get; set; } = string.Empty;
    }
}