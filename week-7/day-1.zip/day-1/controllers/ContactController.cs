﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;
using System.Linq;
using System.Collections.Generic;

namespace WebApplication3.Controllers
{
    public class ContactController : Controller
    {
        // In-memory list to store contacts
        private static List<ContactInfo> contacts = new List<ContactInfo>();

        // Display all contacts
        public IActionResult ShowContacts()
        {
            return View(contacts);
        }

        // Display contact details by ID
        public IActionResult GetContactById(int id)
        {
            var contact = contacts.FirstOrDefault(c => c.ContactId == id);
            if (contact == null)
            {
                return NotFound($"No contact found with ID {id}");
            }
            return View(contact);
        }

        // GET: Show Add Contact form
        public IActionResult AddContact()
        {
            return View();
        }

        // POST: Add new contact
        [HttpPost]
        public IActionResult AddContact(ContactInfo contactInfo)
        {
            if (ModelState.IsValid)
            {
                contacts.Add(contactInfo);
                return RedirectToAction("ShowContacts");
            }
            return View(contactInfo);
        }
    }
}