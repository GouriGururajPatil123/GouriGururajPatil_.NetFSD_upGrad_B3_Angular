﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace WebApplication6.Controllers
{
    [Route("product")]
    public class ProductController : Controller
    {
        private static List<Product> products = new List<Product>();

        // GET: product/index
        [HttpGet("index")]
        public IActionResult Index()
        {
            ViewBag.Products = products;
            return View();
        }

        // POST: product/add
        [HttpPost("add")]
        public IActionResult Add(string name, double price, int quantity)
        {
            products.Add(new Product
            {
                Name = name,
                Price = price,
                Quantity = quantity
            });

            return RedirectToAction("Index");
        }
    }
    public class Product
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
    }
}
