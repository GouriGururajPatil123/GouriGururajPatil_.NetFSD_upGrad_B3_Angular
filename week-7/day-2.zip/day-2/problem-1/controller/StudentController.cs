﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication6.Controllers
{
    [Route("student")]
    public class StudentController : Controller
    {
        // FORM PAGE
        [HttpGet("register")]
        public IActionResult Register()
        {
            return View();
        }

        // FORM SUBMIT
        [HttpPost("register")]
        public IActionResult Register(string studentName, int age, string course)
        {
            // store data temporarily
            TempData["Name"] = studentName;
            TempData["Age"] = age;
            TempData["Course"] = course;

            // go to DIFFERENT PAGE
            return RedirectToAction("Display");
        }

        // DISPLAY PAGE
        [HttpGet("display")]
        public IActionResult Display()
        {
            ViewBag.Name = TempData["Name"];
            ViewBag.Age = TempData["Age"];
            ViewBag.Course = TempData["Course"];

            return View();
        }
    }
}