﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication6.Controllers
{
    [Route("calculator")]
    public class CalculatorController : Controller
    {
        // GET: calculator/add
        [HttpGet("add")]
        public IActionResult Add()
        {
            return View();
        }

        // POST: calculator/add
        [HttpPost("add")]
        public IActionResult Add(int num1, int num2)
        {
            int result = num1 + num2;

            // pass using ViewData
            ViewData["Result"] = result;

            return View();
        }
    }
}