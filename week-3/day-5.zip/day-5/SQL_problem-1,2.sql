CREATE DATABASE EcommDb;
USE EcommDb;

--problem -1

--Level-1 Problem 1: Basic Setup and Data Retrieval in EcommDb
--Scenario
--You are assigned as a database developer to set up the EcommDb database for an automobile retail company. The company wants to verify basic operations such as inserting data and retrieving product and customer information.
--?? Requirements 
--- Create EcommDb and all tables using the provided schema.
--- Insert at least 5 records in categories, brands, products, customers, and stores.
--- Write SELECT queries to retrieve all products with their brand and category names.
--- Retrieve all customers from a specific city.
--- Display total number of products available in each category.
--??? Technical Constraints 
--- Use SQL Server.
-- Use ANSI SQL queries wherever applicable.
-- Do not modify the existing table structure.
-- Ensure foreign key constraints are satisfied while inserting data.


CREATE TABLE Categories(
category_id INT PRIMARY KEY,
category_name VARCHAR(50)
);

CREATE TABLE Brands (
    brand_id INT PRIMARY KEY,
    brand_name VARCHAR(50)
);

CREATE TABLE Products(
product_id INT PRIMARY KEY,
product_name VARCHAR(100),
 brand_id INT,
 category_id INT,
 model_year INT,
 PRICE DECIMAL(10,2),
 FOREIGN KEY (brand_id) REFERENCES Brands(brand_id),
 FOREIGN KEY (category_id) REFERENCES Categories(category_id)
);

CREATE TABLE Customers(
 customer_id INT PRIMARY KEY,
 first_name VARCHAR(50),
    last_name VARCHAR(50),
    city VARCHAR(50),
    phone VARCHAR(20)
);

CREATE TABLE Stores (
    store_id INT PRIMARY KEY,
    store_name VARCHAR(100),
    city VARCHAR(50)
);

INSERT INTO Categories VALUES
(1,'Mountain Bikes'),
(2,'Road Bikes'),
(3,'Electric Bikes'),
(4,'Hybrid Bikes'),
(5,'Kids Bikes');

INSERT INTO Brands VALUES
(1,'Trek'),
(2,'Giant'),
(3,'Specialized'),
(4,'Cannondale'),
(5,'Scott');

INSERT INTO Products VALUES
(1,'Trail Blazer',1,1,2022,1200),
(2,'Road Master',2,2,2021,1500),
(3,'Volt Rider',3,3,2023,2500),
(4,'City Hybrid',4,4,2022,900),
(5,'Junior Speed',5,5,2020,400);

INSERT INTO Customers VALUES
(1,'Rahul','Sharma','Delhi','9876543210'),
(2,'Anita','Patil','Mumbai','9876543211'),
(3,'Vikram','Singh','Delhi','9876543212'),
(4,'Priya','Rao','Bangalore','9876543213'),
(5,'Arjun','Mehta','Mumbai','9876543214');

INSERT INTO Stores VALUES
(1,'Auto Bike Store','Delhi'),
(2,'Speed Wheels','Mumbai'),
(3,'Urban Riders','Bangalore'),
(4,'Mountain Hub','Pune'),
(5,'City Cycles','Chennai');

--1)
--Retrieve all products along with their brand name, category name, model year, and price.
SELECT p.product_name,
       b.brand_name,
	   c.category_name,
	   p.model_year,
	   p.price
FROM Products p
JOIN Brands b ON p.brand_id = b.brand_id
JOIN Categories c ON p.category_id = c.category_id;

--2)
--Retrieve all customers who belong to the city 'Delhi'.
SELECT * FROM Customers WHERE city='Delhi';

--3)
--Display the total number of products available in each category.
SELECT c.category_name, 
COUNT(p.product_id) AS total_products
FROM Categories c
LEFT JOIN Products p ON c.category_id = p.category_id
GROUP BY c.category_name;


--Problem 2

--Level-1 Problem 2: Creating Views and Indexes for Performance
--Scenario
--The management team frequently accesses product and order summary reports. To simplify access and improve performance, they require database views and indexing.
--?? Requirements 
-- Create a view that shows product name, brand name, category name, model year and list price.
-- Create a view that shows order details with customer name, store name and staff name.
-- Create appropriate indexes on foreign key columns.
-- Test performance improvement using execution plan.
--??? Technical Constraints 
-- Views must not duplicate data.
-- Indexes should be created only on frequently searched columns.
-- Do not change table definitions.
-- Follow proper naming conventions.

--1)
--Create a view that shows product name, brand name, category name, model year and list price.
CREATE VIEW vw_ProductDetails AS
SELECT p.product_name,
    b.brand_name,
    c.category_name,
    p.model_year,
    p.price AS list_price FROM Products p
JOIN Brands b ON p.brand_id = b.brand_id
JOIN Categories c ON p.category_id = c.category_id;

SELECT * FROM vw_ProductDetails;

--2)
--Create a view that shows order details with customer name, store name and staff name.
CREATE TABLE Orders(
order_id INT PRIMARY KEY,
customer_id INT,
store_id INT,
 staff_id INT,
 order_date DATE
);
CREATE TABLE Staffs(
staff_id INT PRIMARY KEY,
first_name VARCHAR(50),
last_name VARCHAR(50)
);

INSERT INTO Staffs VALUES
(1,'Ramesh','Kumar'),
(2,'Sita','Sharma'),
(3,'Amit','Verma'),
(4,'Neha','Patil'),
(5,'Raj','Singh');

INSERT INTO Orders VALUES
(1,1,1,1,'2024-01-10'),
(2,2,2,2,'2024-02-15'),
(3,3,3,3,'2024-03-05'),
(4,4,1,4,'2024-04-20'),
(5,5,2,5,'2024-05-11');

CREATE VIEW vw_OrderSummary AS
SELECT o.order_id,
       c.first_name + ''+ c.last_name AS customer_name,
	   s.store_name,
	   st.first_name + '' + st.last_name AS staff_name,
	   o.order_date
FROM Orders o
JOIN Customers c ON o.customer_id = c.customer_id
JOIN Stores s ON o.store_id = s.store_id
JOIN Staffs st ON o.staff_id = st.staff_id;

SELECT * FROM vw_OrderSummary;

--3)

--Index on Product Foreign Keys
CREATE INDEX idx_products_brand ON Products(brand_id);
CREATE INDEX idx_products_category ON Products(category_id);

--Index on Orders Foreign Keys

CREATE INDEX idx_orders_customer ON Orders(customer_id);
CREATE INDEX idx_orders_store ON Orders(store_id);
CREATE INDEX idx_orders_staff ON Orders(staff_id);

SELECT * FROM Products p 
JOIN Brands b ON p.brand_id = b.brand_id;