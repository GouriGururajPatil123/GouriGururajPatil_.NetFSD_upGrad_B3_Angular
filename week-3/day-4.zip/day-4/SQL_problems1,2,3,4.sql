﻿CREATE DATABASE AutoDb;
USE AutoDb;

--Pre-Requisites: Before starting with problem solving, please make sure that you have created a database and restored data  
--AutoDb – SQL Problem Definitions Based on Advanced Querying and Data Manipulation
--Level-1: Problem 1 – Product Analysis Using Nested Queries
--Scenario:
--You are working as a database developer for an automobile retail company. Management wants to identify products that are priced higher than the average price of products in their respective categories.
--📌 Requirements
--1. Retrieve product details (product_name, model_year, list_price).
--2. Compare each product’s price with the average price of products in the same category using a nested query.
--3. Display only those products whose price is greater than the category average.
--4. Show calculated difference between product price and category average.
--5. Concatenate product name and model year as a single column (e.g., 'ProductName (2017)').
--🛠️ Technical Constraints
--• Use subquery in WHERE clause.
--• Use aggregate function (AVG).
--• Use string manipulation functions.
--• Use arithmetic expressions for price difference calculation.


CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    category_id INT,
    model_year INT,
    list_price DECIMAL(10,2)
);

INSERT INTO Products (product_id, product_name, category_id, model_year, list_price) VALUES
(1, 'Hill Master', 1, 2019, 900.00),
(2, 'Road Pro', 1, 2018, 1200.00),
(3, 'Turbo Rider', 2, 2019, 1500.00),
(4, 'Volt Bike', 2, 2019, 2500.00),
(5, 'Speedster', 1, 2020, 1100.00),
(6, 'Mountain Climber', 2, 2020, 1800.00);

-- Query to find products priced above category average
SELECT
    CONCAT(p.product_name, ' (', p.model_year, ')') AS product_display,
    p.model_year,
    p.list_price,
    p.list_price - (
        SELECT AVG(p2.list_price)
        FROM Products p2
        WHERE p2.category_id = p.category_id
    ) AS price_difference
FROM
    Products p
WHERE
    p.list_price > (
        SELECT AVG(p2.list_price)
        FROM Products p2
        WHERE p2.category_id = p.category_id
    )
ORDER BY
    p.category_id,
    p.list_price DESC;


--problem 2

--Level-1: Problem 2 – Customer Activity Classification
--Scenario:
--The company wants to classify customers based on their total order value and identify customers who have placed orders versus those who have not.

--📌 Requirements
--1. Use nested query to calculate total order value per customer.
--2. Classify customers using conditional logic:
 --  - 'Premium' if total order value > 10000
 --  - 'Regular' if total order value between 5000 and 10000
 --  - 'Basic' if total order value < 5000
--3. Use UNION to display customers with orders and customers without orders.
--4. Display full name using string concatenation.
--5. Handle NULL cases appropriately.
--🛠️ Technical Constraints
--• Use CASE statement for classification.
--• Use UNION operator.
--• Use subquery for total calculation.
--• Use JOIN between customers and orders tables.

CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50)
);

CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    order_amount DECIMAL(10,2),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

-- Insert sample data into Customers
INSERT INTO Customers (customer_id, first_name, last_name) VALUES
(1, 'Amit', 'Sharma'),
(2, 'Sneha', 'Patil'),
(3, 'Rahul', 'Kumar'),
(4, 'Anjali', 'Desai'),
(5, 'Vikram', 'Singh');

-- Insert sample data into Orders
INSERT INTO Orders (order_id, customer_id, order_date, order_amount) VALUES
(101, 1, '2026-01-10', 3000.00),
(102, 1, '2026-01-15', 8000.00),
(103, 2, '2026-02-05', 2000.00),
(104, 3, '2026-02-20', 6000.00),
(105, 3, '2026-03-01', 5000.00);

-- Query to classify customers based on total order value
-- Customers WITH orders
SELECT 
    CONCAT(c.first_name, ' ', c.last_name) AS full_name,
    COALESCE((
        SELECT SUM(o.order_amount)
        FROM Orders o
        WHERE o.customer_id = c.customer_id
    ), 0) AS total_order_value,
    CASE
        WHEN COALESCE((
            SELECT SUM(o.order_amount)
            FROM Orders o
            WHERE o.customer_id = c.customer_id
        ), 0) > 10000 THEN 'Premium'
        WHEN COALESCE((
            SELECT SUM(o.order_amount)
            FROM Orders o
            WHERE o.customer_id = c.customer_id
        ), 0) BETWEEN 5000 AND 10000 THEN 'Regular'
        ELSE 'Basic'
    END AS customer_class
FROM Customers c
WHERE c.customer_id IN (
    SELECT DISTINCT customer_id
    FROM Orders
)

UNION

-- Customers WITHOUT orders
SELECT 
    CONCAT(c.first_name, ' ', c.last_name) AS full_name,
    0 AS total_order_value,
    'Basic' AS customer_class
FROM Customers c
WHERE c.customer_id NOT IN (
    SELECT DISTINCT customer_id
    FROM Orders
)
ORDER BY full_name;


--problem 3

--Level-2: Problem 3 – Store Performance and Stock Validation
--Scenario:
--Management wants to evaluate store performance by identifying stores that have sold products but currently have zero stock for those products.
--📌 Requirements
--1. Identify products sold in each store using nested queries.
--2. Compare sold products with current stock using INTERSECT and EXCEPT operators.
--3. Display store_name, product_name, total quantity sold.
--4. Calculate total revenue per product (quantity × list_price – discount).
--5. Update stock quantity to 0 for discontinued products (simulation).
--🛠️ Technical Constraints
--• Use INTERSECT and EXCEPT operators.
--• Use subqueries in FROM clause.
--• Use arithmetic expressions for revenue calculation.
--• Use UPDATE statement for stock modification.

-- Drop tables if they already exist
IF OBJECT_ID('Order_Items', 'U') IS NOT NULL DROP TABLE Order_Items;
IF OBJECT_ID('Orders', 'U') IS NOT NULL DROP TABLE Orders;
IF OBJECT_ID('Stock', 'U') IS NOT NULL DROP TABLE Stock;
IF OBJECT_ID('Stores', 'U') IS NOT NULL DROP TABLE Stores;
IF OBJECT_ID('Products', 'U') IS NOT NULL DROP TABLE Products;

-- Create Stores table
CREATE TABLE Stores (
    store_id INT PRIMARY KEY,
    store_name VARCHAR(50)
);

-- Create Products table
CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    list_price DECIMAL(10,2)
);

-- Create Stock table
CREATE TABLE Stock (
    store_id INT,
    product_id INT,
    quantity INT,
    PRIMARY KEY (store_id, product_id),
    FOREIGN KEY (store_id) REFERENCES Stores(store_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- Create Orders table
CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    store_id INT,
    order_date DATE,
    FOREIGN KEY (store_id) REFERENCES Stores(store_id)
);

-- Create Order_Items table
CREATE TABLE Order_Items (
    order_id INT,
    product_id INT,
    quantity INT,
    discount DECIMAL(10,2),
    PRIMARY KEY (order_id, product_id),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- Insert sample data
INSERT INTO Stores (store_id, store_name) VALUES
(1, 'Downtown Store'),
(2, 'Uptown Store');

INSERT INTO Products (product_id, product_name, list_price) VALUES
(101, 'Bike A', 1000.00),
(102, 'Bike B', 1500.00),
(103, 'Bike C', 2000.00);

INSERT INTO Stock (store_id, product_id, quantity) VALUES
(1, 101, 0),
(1, 102, 5),
(2, 103, 0),
(2, 101, 10);

INSERT INTO Orders (order_id, store_id, order_date) VALUES
(1001, 1, '2026-02-10'),
(1002, 1, '2026-02-15'),
(1003, 2, '2026-03-01');

INSERT INTO Order_Items (order_id, product_id, quantity, discount) VALUES
(1001, 101, 2, 100.00),
(1001, 102, 1, 0.00),
(1002, 102, 3, 50.00),
(1003, 103, 1, 0.00);

-- Query to find products sold but currently have zero stock
WITH SoldProducts AS (
    SELECT 
        s.store_id,
        s.store_name,
        p.product_id,
        p.product_name,
        SUM(oi.quantity) AS total_quantity_sold,
        SUM((oi.quantity * p.list_price) - oi.discount) AS total_revenue
    FROM Stores s
    JOIN Orders o ON s.store_id = o.store_id
    JOIN Order_Items oi ON o.order_id = oi.order_id
    JOIN Products p ON oi.product_id = p.product_id
    GROUP BY s.store_id, s.store_name, p.product_id, p.product_name
),
ZeroStock AS (
    SELECT st.store_id, st.product_id
    FROM Stock st
    WHERE st.quantity = 0
)
SELECT sp.store_name, sp.product_name, sp.total_quantity_sold, sp.total_revenue
FROM SoldProducts sp
JOIN ZeroStock zs
ON sp.store_id = zs.store_id AND sp.product_id = zs.product_id
ORDER BY sp.store_name, sp.product_name;

-- Simulation: Update stock for discontinued products
UPDATE Stock
SET quantity = 0
WHERE store_id = 1 AND product_id = 102;