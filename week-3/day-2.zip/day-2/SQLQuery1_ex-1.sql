CREATE DATABASE EventDb;
USE EventDb;
CREATE TABLE UserInfo(
EmailId VARCHAR(100) PRIMARY KEY,
UserName VARCHAR(50) NOT NULL  CHECK(LEN(UserName)BETWEEN 1 AND 50),
Role VARCHAR(20) NOT NULL CHECK (Role IN('Admin','Participant')),
Password VARCHAR(20) NOT NULL CHECK(LEN(Password) BETWEEN 6 AND 20)
);

INSERT INTO UserInfo VALUES('admin@gmail.com','AdminUser','Admin','admin123');

CREATE TABLE EventDetails(
EventId INT PRIMARY KEY,
EventName VARCHAR(50) NOT NULL CHECK(LEN(EventName) BETWEEN 1 AND 50),
EventCategory VARCHAR(50) NOT NULL CHECK(LEN(EventCategory) BETWEEN 1 AND 50),
EventDate DATETIME NOT NULL,
Description VARCHAR(255) NULL,
Status VARCHAR(20) CHECK(Status IN('Active','In-Active'))
);

INSERT INTO EventDetails VALUES(1,'Summit','Technology','2026-03-10','Annual Tech Event','Active');

CREATE TABLE SpeakersDetails(
SpeakerId INT PRIMARY KEY,
SpeakerName VARCHAR(50) NOT NULL CHECK(LEN(SpeakerName)BETWEEN 1 AND 50)
);

INSERT INTO SpeakersDetails VALUES(101,'Rahul');

CREATE TABLE SessionInfo(
SessionId INT PRIMARY KEY,
EventId INT NOT NULL,
SessionTitle VARCHAR(50) NOT NULL CHECK(LEN(SessionTitle) BETWEEN 1 AND 50),
SpeakerId INT NOT NULL,
Description VARCHAR(255) NOT NULL,
SessionStart DATETIME NOT NULL,
SessionEnd DATETIME NOT NULL,
SessionUrl VARCHAR(255),

FOREIGN KEY(EventId) REFERENCES EventDetails(EventId),
FOREIGN KEY (SpeakerId) REFERENCES SpeakersDetails(SpeakerId)
);

INSERT INTO SessionInfo VALUEs (111,1,'AI',134,'Discussion about AI','2026-03-10 10:00:00','2026-03-10 11:00:00','https://www.google.com/' );

CREATE TABLE ParticipantEventDetails(
Id INT PRIMARY KEY,
ParticipantEmailId VARCHAR(100) NOT NULL,
EventId INT NOT NULL,
SessionId INT NOT NULL,
IsAttended BIT CHECK(IsAttended IN(0,1)),

FOREIGN KEY (ParticipantEmailId) REFERENCES UserInfo(EmailId),
FOREIGN KEY (EventId) REFERENCES EventDetails(EventId),
FOREIGN KEY (SessionId) REFERENCES SessionInfo(SessionId)
);

SELECT * FROM UserInfo;
SELECT * FROM EventDetails;
SELECT * FROM SpeakersDetails;
SELECT * FROM SessionInfo;
SELECT * FROM ParticipantEventDetails;
DROP TABLE SessionInfo;

EXEC sp_helpdb 'eventDb';