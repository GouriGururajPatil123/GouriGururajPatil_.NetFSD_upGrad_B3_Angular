﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace ContactManagement.DAL.Models
{
    public class Department
    {
        [Key]
        public int DepartmentId { get; set; }

        public string DepartmentName { get; set; }

        public ICollection<ContactInfo> Contacts { get; set; }
    }
}