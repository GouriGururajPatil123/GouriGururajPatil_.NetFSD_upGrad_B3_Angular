﻿using ContactManagement.DAL.Models;

namespace ContactManagement.DAL.Repository
{
    public interface IContactRepository
    {
        Task<IEnumerable<ContactInfo>> GetAll();
        Task<ContactInfo> GetById(int id);
        Task Add(ContactInfo contact);
        Task Update(ContactInfo contact);
        Task Delete(int id);
    }
}