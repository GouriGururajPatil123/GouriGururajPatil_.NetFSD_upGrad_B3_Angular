﻿namespace WebApplication13.DataAccessLayer.Models
{
    public class Company
    {
        public int CompanyId { get; set; }
        public string? CompanyName { get; set; }
    }
}