﻿using Dapper;
using WebApplication13.DataAccessLayer.Models;
using System.Collections.Generic;
using System.Linq;

namespace WebApplication13.DataAccessLayer.Repository
{
    public class ContactRepository : IContactRepository
    {
        private readonly DapperContext _context;

        public ContactRepository(DapperContext context)
        {
            _context = context;
        }

        public List<ContactInfo> GetAllContacts()
        {
            var query = @"
                SELECT c.*, comp.CompanyName, dept.DepartmentName
                FROM ContactInfo c
                INNER JOIN Company comp ON c.CompanyId = comp.CompanyId
                LEFT JOIN Department dept ON c.DepartmentId = dept.DepartmentId";

            using (var conn = _context.CreateConnection())
            {
                return conn.Query<ContactInfo>(query).ToList();
            }
        }

        public ContactInfo GetContactById(int id)
        {
            var query = "SELECT * FROM ContactInfo WHERE ContactId=@Id";
            using (var conn = _context.CreateConnection())
            {
                return conn.QuerySingleOrDefault<ContactInfo>(query, new { Id = id });
            }
        }

        public void AddContact(ContactInfo contact)
        {
            var query = @"
                INSERT INTO ContactInfo 
                (FirstName, LastName, EmailId, MobileNo, Designation, CompanyId, DepartmentId)
                VALUES (@FirstName, @LastName, @EmailId, @MobileNo, @Designation, @CompanyId, @DepartmentId)";

            using (var conn = _context.CreateConnection())
            {
                conn.Execute(query, contact);
            }
        }

        public void UpdateContact(ContactInfo contact)
        {
            var query = @"
                UPDATE ContactInfo SET 
                    FirstName=@FirstName, 
                    LastName=@LastName, 
                    EmailId=@EmailId, 
                    MobileNo=@MobileNo,
                    Designation=@Designation, 
                    CompanyId=@CompanyId, 
                    DepartmentId=@DepartmentId
                WHERE ContactId=@ContactId";

            using (var conn = _context.CreateConnection())
            {
                conn.Execute(query, contact);
            }
        }

        public void DeleteContact(int id)
        {
            var query = "DELETE FROM ContactInfo WHERE ContactId=@Id";
            using (var conn = _context.CreateConnection())
            {
                conn.Execute(query, new { Id = id });
            }
        }
    }
}