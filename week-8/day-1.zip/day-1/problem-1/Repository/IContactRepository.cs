﻿using WebApplication13.DataAccessLayer.Models;
using System.Collections.Generic;

namespace WebApplication13.DataAccessLayer.Repository
{
    public interface IContactRepository
    {
        // Get all contacts with Company & Department names
        List<ContactInfo> GetAllContacts();

        // Get a single contact by Id
        ContactInfo GetContactById(int id);

        // Add a new contact
        void AddContact(ContactInfo contact);

        // Update an existing contact
        void UpdateContact(ContactInfo contact);

        // Delete a contact by Id
        void DeleteContact(int id);
    }
}