﻿using Microsoft.AspNetCore.Mvc;
using WebApplication13.DataAccessLayer.Models;
using WebApplication13.DataAccessLayer.Repository;

namespace WebApplication13.Controllers
{
    public class ContactController : Controller
    {
        private readonly IContactRepository _repo;

        public ContactController(IContactRepository repo)
        {
            _repo = repo;
        }

        // LIST
        public IActionResult Index()
        {
            var data = _repo.GetAllContacts();
            return View(data);
        }

        // CREATE
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(ContactInfo contact)
        {
            _repo.AddContact(contact);
            return RedirectToAction("Index");
        }

        // EDIT GET
        public IActionResult Edit(int id)
        {
            var contact = _repo.GetContactById(id);
            if (contact == null) return NotFound();
            return View(contact);
        }

        // EDIT POST
        [HttpPost]
        public IActionResult Edit(ContactInfo contact)
        {
            _repo.UpdateContact(contact);
            return RedirectToAction("Index");
        }

        // DELETE GET
        public IActionResult Delete(int id)
        {
            var contact = _repo.GetContactById(id);
            if (contact == null) return NotFound();
            return View(contact);
        }

        // DELETE POST
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            _repo.DeleteContact(id);
            return RedirectToAction("Index");
        }
    }
}