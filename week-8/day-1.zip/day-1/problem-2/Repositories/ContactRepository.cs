﻿using Dapper;
using System.Data;
using System.Data.SqlClient;

public class ContactRepository : IContactRepository
{
    private readonly string _connStr;

    public ContactRepository(IConfiguration config)
    {
        _connStr = config.GetConnectionString("DefaultConnection");
    }

    private IDbConnection GetConnection()
    {
        return new SqlConnection(_connStr);
    }

    // JOIN Query
    public IEnumerable<ContactInfo> GetAll()
    {
        using (var db = GetConnection())
        {
            string sql = @"
            SELECT c.*, 
                   comp.CompanyName, 
                   d.DepartmentName
            FROM ContactInfo c
            INNER JOIN Company comp ON c.CompanyId = comp.CompanyId
            LEFT JOIN Department d ON c.DepartmentId = d.DepartmentId";

            return db.Query<ContactInfo>(sql);
        }
    }

    public ContactInfo GetById(int id)
    {
        using (var db = GetConnection())
        {
            string sql = @"
            SELECT c.*, 
                   comp.CompanyName, 
                   d.DepartmentName
            FROM ContactInfo c
            INNER JOIN Company comp ON c.CompanyId = comp.CompanyId
            LEFT JOIN Department d ON c.DepartmentId = d.DepartmentId
            WHERE c.ContactId = @Id";

            return db.QueryFirstOrDefault<ContactInfo>(sql, new { Id = id });
        }
    }

    public void Add(ContactInfo contact)
    {
        using (var db = GetConnection())
        {
            string sql = @"
            INSERT INTO ContactInfo (Name, Email, Phone, CompanyId, DepartmentId)
            VALUES (@Name, @Email, @Phone, @CompanyId, @DepartmentId)";

            db.Execute(sql, contact);
        }
    }

    public void Update(ContactInfo contact)
    {
        using (var db = GetConnection())
        {
            string sql = @"
            UPDATE ContactInfo
            SET Name = @Name,
                Email = @Email,
                Phone = @Phone,
                CompanyId = @CompanyId,
                DepartmentId = @DepartmentId
            WHERE ContactId = @ContactId";

            db.Execute(sql, contact);
        }
    }

    public void Delete(int id)
    {
        using (var db = GetConnection())
        {
            string sql = "DELETE FROM ContactInfo WHERE ContactId = @Id";
            db.Execute(sql, new { Id = id });
        }
    }

    public IEnumerable<Company> GetCompanies()
    {
        using (var db = GetConnection())
        {
            return db.Query<Company>("SELECT * FROM Company");
        }
    }

    public IEnumerable<Department> GetDepartments()
    {
        using (var db = GetConnection())
        {
            return db.Query<Department>("SELECT * FROM Department");
        }
    }
}