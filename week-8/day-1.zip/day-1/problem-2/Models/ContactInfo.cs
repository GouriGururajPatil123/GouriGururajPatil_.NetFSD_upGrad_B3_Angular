﻿public class ContactInfo
{
    public int ContactId { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }

    public int CompanyId { get; set; }
    public int? DepartmentId { get; set; }

    // Display fields (JOIN)
    public string CompanyName { get; set; }
    public string DepartmentName { get; set; }
}