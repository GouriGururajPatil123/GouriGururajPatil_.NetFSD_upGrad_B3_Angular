SELECT * FROM ContactInfo;

DROP TABLE ContactInfo;

CREATE TABLE ContactInfo (
    ContactId INT PRIMARY KEY IDENTITY,
    Name VARCHAR(100),
    Email VARCHAR(100),
    Phone VARCHAR(20),
    CompanyId INT,
    DepartmentId INT NULL
);

SELECT COLUMN_NAME 
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ContactInfo';

DROP TABLE ContactInfo;

CREATE TABLE ContactInfo (
    ContactId INT PRIMARY KEY IDENTITY(1,1),

    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100),
    Phone VARCHAR(20),

    CompanyId INT NOT NULL,
    DepartmentId INT NULL
);

INSERT INTO ContactInfo (Name, Email, Phone, CompanyId, DepartmentId)
VALUES
('Amit', 'amit@gmail.com', '9999999999', 1, 1),
('Priya', 'priya@gmail.com', '8888888888', 2, NULL);

SELECT 
    c.ContactId,
    c.Name,
    c.Email,
    c.Phone,
    comp.CompanyName,
    d.DepartmentName
FROM ContactInfo c
INNER JOIN Company comp ON c.CompanyId = comp.CompanyId
LEFT JOIN Department d ON c.DepartmentId = d.DepartmentId;

SELECT * FROM ContactInfo;