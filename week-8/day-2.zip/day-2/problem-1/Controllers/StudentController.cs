﻿using Microsoft.AspNetCore.Mvc;

public class StudentController : Controller
{
    private readonly StudentRepository _repo;

    public StudentController(StudentRepository repo)
    {
        _repo = repo;
    }

    //  Students with Course
    public IActionResult StudentsWithCourse()
    {
        var data = _repo.GetStudentsWithCourse();
        return View(data);
    }

    //  Courses with Students
    public IActionResult CoursesWithStudents()
    {
        var data = _repo.GetCoursesWithStudents();
        return View(data);
    }
}