CREATE DATABASE CollegeDB;

USE CollegeDB;

-- Course Table
CREATE TABLE Course (
    CourseId INT PRIMARY KEY IDENTITY,
    CourseName NVARCHAR(100) NOT NULL
);

-- Student Table
CREATE TABLE Student (
    StudentId INT PRIMARY KEY IDENTITY,
    StudentName NVARCHAR(100) NOT NULL,
    CourseId INT,
    FOREIGN KEY (CourseId) REFERENCES Course(CourseId)
);

-- Sample Data
INSERT INTO Course (CourseName) VALUES ('Computer Science'), ('Mechanical'), ('Civil');

INSERT INTO Student (StudentName, CourseId)
VALUES ('Amit', 1), ('Rahul', 1), ('Sneha', 2);

