﻿using Dapper;
using Microsoft.Data.SqlClient;

public class StudentRepository
{
    private readonly string _connStr;

    public StudentRepository(IConfiguration config)
    {
        _connStr = config.GetConnectionString("DefaultConnection");
    }

    private SqlConnection GetConnection()
    {
        return new SqlConnection(_connStr);
    }

    // 🔹 Get Students with Course (JOIN)
    public IEnumerable<Student> GetStudentsWithCourse()
    {
        using (var db = GetConnection())
        {
            string sql = @"SELECT s.StudentId, s.StudentName, s.CourseId,
                                  c.CourseId, c.CourseName
                           FROM Student s
                           INNER JOIN Course c ON s.CourseId = c.CourseId";

            var data = db.Query<Student, Course, Student>(
                sql,
                (student, course) =>
                {
                    student.Course = course;
                    return student;
                },
                splitOn: "CourseId"
            );

            return data;
        }
    }

    // 🔹 Get Courses with Students (One-to-Many)
    public IEnumerable<Course> GetCoursesWithStudents()
    {
        using (var db = GetConnection())
        {
            string sql = @"SELECT c.CourseId, c.CourseName,
                                  s.StudentId, s.StudentName, s.CourseId
                           FROM Course c
                           LEFT JOIN Student s ON c.CourseId = s.CourseId";

            var courseDict = new Dictionary<int, Course>();

            var result = db.Query<Course, Student, Course>(
                sql,
                (course, student) =>
                {
                    if (!courseDict.TryGetValue(course.CourseId, out var currentCourse))
                    {
                        currentCourse = course;
                        currentCourse.Students = new List<Student>();
                        courseDict.Add(currentCourse.CourseId, currentCourse);
                    }

                    if (student != null)
                        currentCourse.Students.Add(student);

                    return currentCourse;
                },
                splitOn: "StudentId"
            );

            return courseDict.Values;
        }
    }
}