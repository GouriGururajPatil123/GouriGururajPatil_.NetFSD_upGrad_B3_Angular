﻿using Microsoft.AspNetCore.Mvc;
using ContactManagement.API.Data;
using ContactManagement.API.Models;
using ContactManagement.API.Exceptions;

namespace ContactManagement.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<ContactsController> _logger;

        public ContactsController(AppDbContext context, ILogger<ContactsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            _logger.LogInformation("Fetching all contacts");
            return Ok(_context.Contacts.ToList());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var contact = _context.Contacts.Find(id);

            if (contact == null)
                throw new NotFoundException($"Contact with Id {id} not found");

            return Ok(contact);
        }

        [HttpPost]
        public IActionResult Create(Contact contact)
        {
            if (string.IsNullOrEmpty(contact.Name))
                throw new BadRequestException("Name is required");

            _context.Contacts.Add(contact);
            _context.SaveChanges();

            _logger.LogInformation("Contact created with Id {Id}", contact.Id);

            return Ok(contact);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Contact updated)
        {
            var contact = _context.Contacts.Find(id);

            if (contact == null)
                throw new NotFoundException("Contact not found");

            contact.Name = updated.Name;
            contact.Email = updated.Email;
            contact.Phone = updated.Phone;

            _context.SaveChanges();

            _logger.LogInformation("Contact updated with Id {Id}", id);

            return Ok(contact);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var contact = _context.Contacts.Find(id);

            if (contact == null)
                throw new NotFoundException("Contact not found");

            _context.Contacts.Remove(contact);
            _context.SaveChanges();

            _logger.LogInformation("Contact deleted with Id {Id}", id);

            return Ok("Deleted successfully");
        }
    }
}