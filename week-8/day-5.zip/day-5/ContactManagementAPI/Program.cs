using ContactManagement.API.Data;
using ContactManagement.API.Middleware;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// ================= CONTROLLERS =================
builder.Services.AddControllers();

// ================= SWAGGER =================
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ================= DATABASE =================
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseInMemoryDatabase("ContactDb"));

// ================= LOGGING =================
builder.Logging.ClearProviders();
builder.Logging.AddConsole();

var app = builder.Build();

// ================= SWAGGER MIDDLEWARE =================
app.UseSwagger();
app.UseSwaggerUI();

// ================= CUSTOM MIDDLEWARE =================
app.UseMiddleware<ExceptionMiddleware>();

app.UseAuthorization();

app.MapControllers();

app.Run();