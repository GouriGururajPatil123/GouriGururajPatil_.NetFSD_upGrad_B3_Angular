using WebApplication17.DataAccess;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllers();

// FIX: Register repository
builder.Services.AddSingleton<IContactRepository, ContactRepository>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<IContactRepository, ContactRepository>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();