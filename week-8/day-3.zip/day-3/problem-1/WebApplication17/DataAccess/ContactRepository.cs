﻿using WebApplication17.Models;

namespace WebApplication17.DataAccess
{
    public class ContactRepository : IContactRepository
    {
        public static List<ContactInfo> contacts = new List<ContactInfo>();
        private static int _nextId = 1;

        // Static constructor to seed default contacts
        static ContactRepository()
        {
            contacts.Add(new ContactInfo
            {
                ContactId = _nextId++,
                FirstName = "Gouri",
                LastName = "Patil",
                EmailId = "gouri@gmail.com",
                MobileNo = 9876543210,
                Designation = "Developer",
                CompanyId = 1,
                DepartmentId = 2
            });

            contacts.Add(new ContactInfo
            {
                ContactId = _nextId++,
                FirstName = "Ravi",
                LastName = "Kumar",
                EmailId = "ravi@gmail.com",
                MobileNo = 9123456780,
                Designation = "Manager",
                CompanyId = 1,
                DepartmentId = 1
            });

            
            contacts.Add(new ContactInfo
            {
                ContactId = _nextId++,
                FirstName = "Sneha",
                LastName = "Singh",
                EmailId = "sneha@gmail.com",
                MobileNo = 9456789012,
                Designation = "Designer",
                CompanyId = 2,
                DepartmentId = 3
            });
        }

        public async Task<IEnumerable<ContactInfo>> GetAllAsync()
        {
            return await Task.FromResult(contacts);
        }

        public async Task<ContactInfo?> GetByIdAsync(int id)
        {
            var contact = contacts.FirstOrDefault(c => c.ContactId == id);
            return await Task.FromResult(contact);
        }

        public async Task<ContactInfo> AddAsync(ContactInfo contact)
        {
            contact.ContactId = _nextId++;
            contacts.Add(contact);
            return await Task.FromResult(contact);
        }

        public async Task<bool> UpdateAsync(int id, ContactInfo contact)
        {
            var existing = contacts.FirstOrDefault(c => c.ContactId == id);
            if (existing == null) return await Task.FromResult(false);

            existing.FirstName = contact.FirstName;
            existing.LastName = contact.LastName;
            existing.EmailId = contact.EmailId;
            existing.MobileNo = contact.MobileNo;
            existing.Designation = contact.Designation;
            existing.CompanyId = contact.CompanyId;
            existing.DepartmentId = contact.DepartmentId;

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var contact = contacts.FirstOrDefault(c => c.ContactId == id);
            if (contact == null) return await Task.FromResult(false);

            contacts.Remove(contact);
            return await Task.FromResult(true);
        }
    }
}