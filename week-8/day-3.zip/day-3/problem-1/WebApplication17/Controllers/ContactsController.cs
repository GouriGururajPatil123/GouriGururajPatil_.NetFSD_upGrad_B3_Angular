﻿using Microsoft.AspNetCore.Mvc;
using WebApplication17.DataAccess;
using WebApplication17.Models;

namespace WebApplication17.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactsController : ControllerBase
    {
        private readonly IContactRepository _repo;

        public ContactsController(IContactRepository repo)
        {
            _repo = repo;
        }

        // GET: api/contacts
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var contacts = await _repo.GetAllAsync();
            return Ok(new { message = "Contacts retrieved successfully", contacts });
        }

        // GET: api/contacts/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var contact = await _repo.GetByIdAsync(id);
            if (contact == null)
                return NotFound(new { message = $"Contact with ID {id} not found." });

            return Ok(new { message = $"Contact with ID {id} retrieved successfully", contact });
        }

        // POST: api/contacts
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] ContactInfo contact)
        {
            if (!ModelState.IsValid)
                return BadRequest(new { message = "Invalid contact data", errors = ModelState.Values.SelectMany(v => v.Errors) });

            var created = await _repo.AddAsync(contact);
            return CreatedAtAction(nameof(GetById), new { id = created.ContactId },
                new { message = "Contact added successfully", contact = created });
        }

        // PUT: api/contacts/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] ContactInfo contact)
        {
            if (!ModelState.IsValid)
                return BadRequest(new { message = "Invalid contact data", errors = ModelState.Values.SelectMany(v => v.Errors) });

            var updated = await _repo.UpdateAsync(id, contact);
            if (!updated)
                return NotFound(new { message = $"Contact with ID {id} not found." });

            return Ok(new { message = $"Contact with ID {id} updated successfully", contact });
        }

        // DELETE: api/contacts/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _repo.DeleteAsync(id);
            if (!deleted)
                return NotFound(new { message = $"Contact with ID {id} not found." });

            return Ok(new { message = $"Contact with ID {id} deleted successfully." });
        }
    }
}